<?php

include("./connect.php");

// require ('./Zenoph/Notify/AutoLoader.php');
require ('./admin/Zenoph/Notify/AutoLoader.php');
use Zenoph\Notify\Enums\AuthModel;
use Zenoph\Notify\Request\NotifyRequest;
use Zenoph\Notify\Request\CreditBalanceRequest;
use Zenoph\Notify\Request\AuthRequest;
use Zenoph\Notify\Request\SMSRequest;

if(isset($_GET['contact'])){
    $cont = $_GET['contact'];
    $query = "SELECT firstname,lastname,department,yrlevel,indexNo,paymentconfirmMsg,studentno,contact, password FROM students WHERE contact = '$cont'";

if($result6 = mysqli_query($con, $query)) {

if($row = mysqli_fetch_assoc($result6)){
  $stuname = $row['lastname']." ".$row['firstname'];
 $studentNo = $row["studentno"];
 $stuindex = $row["indexNo"];
 $yrLvl =  $row["yrlevel"];
 $depart =  $row["course"]; 
 $msgPayment = $row['paymentconfirmMsg'];
 $contact = $row['contact'];
 $pass = md5($row['password']);


//  set up the sms integration
try {
    // set host
    NotifyRequest::setHost('api.smsonlinegh.com');

    
      // initialise authentication request object
  $ar = new AuthRequest();

  // set API key authentication
  $ar->setAuthModel(AuthModel::API_KEY);
  $ar->setAuthApiKey("fe412a8328e39b9096207a02b3c17cb1dda55dbc885907c2f9e332c195d20c1a");

  // authenticate for auth profile
  $ap = $ar->authenticate();

   // Initialise SMS request with the authentication profile
   $sr = new SMSRequest($ap);

   // set message properties and submit
   $sr->setMessage("Dear $stuname, \r\nUse this code ($pass) to log in your account and create a new password after you login. <br>Thank you.");
//   $sr->setSender("KsTU_RESIT");
   $sr->setSender("OR Square");
//    $sr->setSender("KsTU");
   $sr->addDestination($contact);
   $sr->submit();
 
   // Initialise balance request with the authentication profile
   $br = new CreditBalanceRequest($ap);
   $bRes = $br->submit();
   $_SESSION['prompt'] ="SMS Message sent Successfully.";
   header("location: index.php");
} 

catch (Exception $ex) {
    die (printf("Error: %s.", $ex->getMessage()));

}


            }
            else{
    echo "<script> window.alert('Message not sent'); </script>";
   $_SESSION['errprompt'] ="SMS Message sent Unsuccessfully.";
   header("location: index.php");

                }
                }else
            // echo mysqli_connect_error();
             
   $_SESSION['errprompt'] = mysqli_connect_error()." Err";
   header("location: index.php");
}else
// echo mysqli_error($con);
header("location: index.php");

// 
?>