<nav class="navbar navbar-default">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
     
      <a class="navbar-brand" href="index.php">&copy; <?php echo date('Y'); ?>                        Developed by WeDev and wWw </a>

    </div>

    


  </div><!-- /.container-fluid -->
<?php
  // Create a session variable called something like this after you start the session:
// $_SESSION['user_start'] = time();
 
// // Then when they get to submitting the payment, just check whether they're within the 5 minute window
// if (time() - $_SESSION['user_start'] < 30) { // 300 seconds = 5 minutes
//     // they're within the 5 minutes so save the details to the database
// } else {
//     // sorry, you're out of time
//    unset($_SESSION['user_start']); // and unset any other session vars for this task
   
// }

?>
</nav>

