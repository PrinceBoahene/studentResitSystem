<?php

// use PHPMailer\PHPMailer\PHPMailer;


// require_once('./PHPMailer/PHPMailerAutoload.php');

// require_once('./PHPMailer/class.smtp.php');

// $mail = new PHPMailer();
// $mail-> isSMTP();
// $mail-> SMTPAuth = true;
// $mail-> SMTPSecure = 'ssl';
// $mail-> Host = 'smtp.gmail.com';
// $mail-> Port = '465';
// $mail-> Username = 'nanakayprince19@gmail.com';
// $mail-> Password = '12541245';
// $mail-> setFrom('nanakayprince19@gmail.com','');
// $mail-> Subject = 'Hello Prince';
// $mail-> Body = 'I love your hardwork';
// $mail-> addAddress('boaheneprince24@gmail.com','prince boahene');
// $mail-> send();

// if(!$mail->send()){
//     echo "Unsuccessful   ". $mail->ErrorInfo;
// }else{
//     echo "successful";
// }
//  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.>
# ------------------
# Create a campaign\
# ------------------
// # Include the Sendinblue library\
// require_once(__DIR__ . "/APIv3-php-library/autoload.php");
// # Instantiate the client\
// SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey("api-key", "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");
// $api_instance = new SendinBlue\Client\Api\EmailCampaignsApi();
// $emailCampaigns = new \SendinBlue\Client\Model\CreateEmailCampaign();
// # Define the campaign settings\
// $email_campaigns['name'] = "Campaign sent via the API";
// $email_campaigns['subject'] = "My subject";
// $email_campaigns['sender'] = array("OR square","wedev1250@gmail.com");
// $email_campaigns['type'] = "classic";
// # Content that will be sent\
// "htmlContent"=> "Congratulations! You successfully sent this example campaign via the Sendinblue API.";
// # Select the recipients\
// "recipients"=> array("listIds"=> [2, 7]);
// # Schedule the sending in one hour\
// // "scheduledAt"=> ("2018-01-01 00:00:01");
// # Make the call to the client\
// try {
// $result = $api_instance->createEmailCampaign($emailCampaigns);
// print_r($result);
// } catch (Exception $e) {
// echo 'Exception when calling EmailCampaignsApi->createEmailCampaign: ', $e->getMessage(), PHP_EOL;
// }
// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.
include("./connect.php");

require ('./Zenoph/Notify/AutoLoader.php');
use Zenoph\Notify\Enums\AuthModel;
use Zenoph\Notify\Request\NotifyRequest;
use Zenoph\Notify\Request\CreditBalanceRequest;
use Zenoph\Notify\Request\AuthRequest;
use Zenoph\Notify\Request\SMSRequest;


if(isset($_GET['smsMSG'])){
    $stuNum = $_GET['smsMSG'];
    $query = "SELECT firstname,lastname,department,yrlevel,indexNo,paymentconfirmMsg,studentno,contact FROM students WHERE studentno = '$stuNum'";

if($result6 = mysqli_query($con, $query)) {

if($row = mysqli_fetch_assoc($result6)){
  $stuname = $row['lastname']." ".$row['firstname'];
 $studentNo = $row["studentno"];
 $stuindex = $row["indexNo"];
 $yrLvl =  $row["yrlevel"];
 $depart =  $row["course"]; 
 $msgPayment = $row['paymentconfirmMsg'];
 $contact = $row['contact'];


//  set up the sms integration
try {
    // set host
    NotifyRequest::setHost('api.smsonlinegh.com');

    
      // initialise authentication request object
  $ar = new AuthRequest();

  // set API key authentication
  $ar->setAuthModel(AuthModel::API_KEY);
  $ar->setAuthApiKey("fe412a8328e39b9096207a02b3c17cb1dda55dbc885907c2f9e332c195d20c1a");

  // authenticate for auth profile
  $ap = $ar->authenticate();

   // Initialise SMS request with the authentication profile
   $sr = new SMSRequest($ap);

   // set message properties and submit
   $sr->setMessage("Dear $stuname, \r\nThank you for making $msgPayment of your registered trial courses. Kindly visit https://kstu-orsquare.org download the paid registered courses. <br>Thank you.");
//   $sr->setSender("KsTU_RESIT");
   $sr->setSender("OR Square");
//    $sr->setSender("KsTU");
   $sr->addDestination($contact);
   $sr->submit();
 
   // Initialise balance request with the authentication profile
   $br = new CreditBalanceRequest($ap);
   $bRes = $br->submit();
   $_SESSION['prompt'] ="Message sent Successfully.";
   header("location: addpayment.php");
} 

catch (Exception $ex) {
    die (printf("Error: %s.", $ex->getMessage()));

}


            }
            else{
    echo "<script> window.alert('Message not sent'); </script>";
   $_SESSION['errprompt'] ="Message sent Unsuccessfully.";
   header("location: addpayment.php");

                }
                }else
            // echo mysqli_connect_error();
             
   $_SESSION['errprompt'] = mysqli_connect_error()." Err";
   header("location: addpayment.php");
}else
// echo mysqli_error($con);
header("location: paymentlist.php");

// 
?>