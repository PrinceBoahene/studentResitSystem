<?php
//session_start();// Starting Session
include("connect.php");
$user_check= $_SESSION["id"];// Storing Session
// SQL Query To Fetch Complete Information Of User
$ses_sql=mysqli_query($con,"select * from administor where id = '$user_check'");
//echo $user_check;
$row = mysqli_fetch_assoc($ses_sql);
$my_id=$row['id'];
$my_fname =$row['name'];
$my_lname =$row['adminID'];
// $my_gender =$row['gender'];
// $my_blood =$row['blood'];
// $my_mobile=$row['mobile'];
// $my_email =$row['email'];
// $my_address=$row['address'];
// $my_department=$row['deptname'];
// $my_birthdate=$row['dob'];
// $my_file = echo ".'<img src="./uploaded/132064.jpg" >'. " ;

  
// $my_category=$row['catname'];
if(!isset($my_fname)){
mysqli_close($con); // Closing Connection
//header('Location: usertbl.php'); // Redirecting To Home Page
}
?>
