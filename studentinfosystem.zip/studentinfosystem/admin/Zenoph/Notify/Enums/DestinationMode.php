<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
    namespace Zenoph\Notify\Enums;
    
    class DestinationMode {
        const DM_NONE = 0;
        const DM_ADD = 1;
        const DM_UPDATE = 2;
        const DM_DELETE = 3;
    }