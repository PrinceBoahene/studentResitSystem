<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
    namespace Zenoph\Notify\Enums;
    
    class DestinationValidation {
        const DV_OK = 2401;
        const DV_ERR_QUERY_TIME = 2402;
        const DV_ERR_DESTINATION_ID = 2403;
        const DV_UNKNOWN = 2404;
    }