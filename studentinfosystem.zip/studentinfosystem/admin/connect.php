<?php
$server="localhost";
$username1="root";
$password="";
$database="studentinfosystem";
$con=mysqli_connect($server,$username1,$password,$database);
if(!$con)
  
  die( "Not connected") or mysqli_connect_error();
// mysql_select_db();   


?>