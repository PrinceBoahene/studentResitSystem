<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>
	
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Upturn Smart Online Exam System" />
<script src="/assets/js/DT_bootstrap.js"></script>
</head> 
<body>
<div class="page-container">
   <!--/content-inner-->
<div class="left-content">
<div class="mother-grid-inner">
<?php 
session_start();

if($_SESSION["id"]==true)
{

 include("connect.php");
include("header.php"); ?>

	<ol class="breadcrumb">
	             <li class="breadcrumb-item text-white" ><h4 ><a href = "http://www.upturnit.com/product.php" onclick = "getConfirm(this.href);" class=" btn btn-primary hvr-icon-float-away col-9">Add Student </a></h4></li>
                <center><li class="breadcrumb-item"><h4><a href="">Student List</a></h4></li></center>
            </ol>
<!--grid
 	<div class="validation-system">
 		
 		<div class="validation-form">
 	-->
  	    
<?php

include("connect.php");
// `students`(`id`, `password`, `studentno`, `firstname`, `lastname`, `course`, `yrlevel`, `date_joined`,
//  `email`, `indexNo`, `contact`, `Faculty`, `session`
$sql="SELECT firstname,lastname,studentno,indexNo,yrlevel,contact,Faculty,department,session,status FROM students";
$result = mysqli_query($con,$sql);
?>
<div class="agile-grids">
<div class="agile-tables">
<div class="w3l-table-info">
<h2>List of Students</h2>
<table width="100%" id="example">
<thead>
<tr>
               <th align="left">No</th>
			   <th align="left">Name</th>
			   <th align="left">Student No.</th>
			   <th align="left">Index No.</th>
			   <th align="left">Level</th>
			   <th align="left">Contact</th>
			   <th align="left">Faculty</th>
			   <th align="left">Department</th>
			   <th align="left">Session</th>
			   <!-- <th align="left">Department</th> -->
			   <!-- <th align="left">Category</th>
			   <th align="left">File</th> -->
			   
			   <th align="left">Action</th>
			    
</tr>
</thead>
<tbody>
<?php $no = 0; while($rows=mysqli_fetch_array($result))
{ $no +=1;
	extract($rows);
	?>

<!-- // `students`(`id`, `password`, `studentno`, `firstname`, `lastname`, `course`, `yrlevel`, `date_joined`, -->
<!-- //  `email`, `indexNo`, `contact`, `Faculty`, `session` -->
    <tr>
    <td><?php echo $no; ?></td>
	<td><?php echo $rows['lastname']." ".$rows['firstname'];?></td>
    <td><?php echo $rows['studentno'];?></td>
	<td><?php echo $rows['indexNo'];?></td>

	<!-- get name of yrlevel -->
	<?php   $year = "year"; 
          $query_year = "SELECT * FROM stuyearnsessions WHERE id = '".$rows["yrlevel"]."' and type = '" . $year ."'";
        $result_year = mysqli_query($con, $query_year);
        $row_year = mysqli_fetch_assoc($result_year);
          if($row_year){
                        ?>
	<td><?php echo $row_year['typename'];?></td>
	<?php } else{
             ?>
	<td><?php echo "Unknown";?></td>
    <?php }	?>
<!-- contact -->
	<td><?php echo $rows['contact'];?></td>

<!-- get name of faculty -->
<?php   $fact = "Faculty"; 
			$query_fat = "SELECT * FROM stufacultydepart WHERE id = '".$rows["Faculty"]."' and type = '" . $fact ."'";
			$result_fat = mysqli_query($con, $query_fat);
			$row_fat = mysqli_fetch_assoc($result_fat);
				if($row_fat){
	?>
	<td><?php echo $row_fat['typename'];?></td>
	<?php 	}
				else{		?>
		<td><?php  echo "Unknown";?></td>

	<?php		}	?>

<!-- get name of department -->
	<?php   $departo = "Department"; 
			$query_departo = "SELECT * FROM stufacultydepart WHERE id = '".$rows["department"]."' and type = '" . $departo ."'";
			$result_departo = mysqli_query($con, $query_departo);
			$row_departo = mysqli_fetch_assoc($result_departo);
				if($row_departo){
	?>
		<td><?php  echo $row_departo['typename'];?></td>
	<?php 						}
				else{		?>
		<td><?php  echo "Unknown";?></td>

	<?php		}	?>

<!-- get name for session -->
<?php   $sess = "session"; 
            $query_sess = "SELECT * FROM stuyearnsessions WHERE id = '".$rows["session"]."' and type = '" . $sess ."'";
            $result_sess = mysqli_query($con, $query_sess);
           $row_sess = mysqli_fetch_assoc($result_sess);
                  if($row_sess){
                                ?>
	<td><?php echo $row_sess['typename'];?></td>
	<?php }
             else{
                ?>
	<td><?php echo "Unknown";?></td>
	<?php } 	?>
	<td>
	

    <?php
$status=$rows['status'];
if(($status)=='0')
{
?>

<!-- href="deletenotice.php?id=<?php //echo $rows['noteid']; ?>"  -->
    <!-- onclick="return confirm('Are you sure you wish to delete this Record?');"> -->
<!-- <button class="btn bg-danger"> -->
<a href = "studaction.php?status_activate=<?php echo $rows['studentno']; ?>" 
onclick = "return confirm('Do you want to Activate <?php echo $rows['firstname']. " ". $rows['lastname'] ?>')"> <span class='glyphicon glyphicon-remove'></span> </a>
<?php
}
if(($status)=='1')
{
?>
<!-- <button class="btn bg-success text-white "> -->
<a href = "studaction.php?status_activate=<?php echo $rows['studentno']; ?>" onclick = "return confirm('Do you want to De - Activate <?php echo $rows['firstname']." ". $rows['lastname'] ?>')"> <span class='glyphicon glyphicon-ok'></span> </a>

<!-- </button> -->

<?php
}
?>

	<!-- <button class="btn btn-dark text-white "> -->
		<a href = "studaction.php?status_del=<?php echo $rows['studentno']; ?>"  onclick = "return confirm('Do you want to Delete <?php echo $rows['firstname']." ". $rows['lastname'] ?>')"><span class='glyphicon glyphicon-trash'> </span></a>
	 <!-- </button> -->
 
	<!-- <button class="btn bg-alert dark text-white "> -->
		<a href = "./editstudent.php" onclick = "return confirm('Do you want to Edit <?php echo $rows['firstname']." ". $rows['lastname'] ?>')"> <span class='glyphicon glyphicon-edit'></span></a>
	<!-- </button> -->
	</td>
    </tr>
<?php 
}
?>
</tbody>
</table>
</div>
</div>
</div>
	
<?php include("footer.php"); ?>
</div></div>

	<?php include("sidebar.php"); ?>
	
	<?php }
else
	header('location:index.php');
?>
	</div>
</body>
<!--popup script start -->
<script type = "text/javascript">

function getConfirm(l)
{
  if(arguments[0] != null)
  {
    if(window.confirm('Get Full Source Code at reasonable cost  ' + l + '?\n'))
    {
      location.href = l;
    }
    
    else
    {
      event.cancelBubble = true;
      event.returnValue = false;
      return false;
    }
  }
  
  else
  {
    return false;
  }
  return;
}
</script>

	<!--popup script end -->
	

</html>