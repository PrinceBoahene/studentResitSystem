<?php
  session_start();

// require('./../fpdf/fpdf.php');
require('./../fpdf/fpdf.php');
include('./connect.php');
$userID = $_SESSION['id'];


// class PDF extends FPDF
// {
// /* Page header */
// function Header()
// {
    
//     $this->SetFont('Arial','B',15);
//     /* Move to the right */
//     $this->Cell(60);
  
//     $this->Cell(70,10,'Page Heading',1,0,'C');
    
// }
// /* Page footer */
// function Footer()
// {
//     /* Position at 1.5 cm from bottom */
//     $this->SetY(-15);
//     /* Arial italic 8 */
//     $this->SetFont('Arial','I',8);
//     /* Page number */
//     $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
// }
// }



$pdf = new FPDF();
///var_dump(get_class_methods($pdf));
// set the title
// $pdf->SetTitle('$stuNo_Resit_receipt');

// $pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',10);

$pdf->Ln(8);
$pdf->Cell(50,10,'Printed Date: '.date('d-m-Y').'',0,"R");
// $pdf->ln(3);

// $sql = "SELECT  `id`,`stuNo`, `coursecode`, `coursename`, `yrtrialed`, `currentdate`, `payment`, 
// `confirmedPayment` FROM `tbtrialedcourses` WHERE confirmedPayment = '$yes'"; WHERE confirmedPayment";
$depert = "Department of Computer Science";
// student information
$query2="SELECT * FROM stufacultydepart where typename = '$depert'";
// $result2 = mysqli_query($con, $query2);

if($result2 = mysqli_query($con, $query2)) {

    $row2 = mysqli_fetch_assoc($result2);
    $pdf->cell(30,5,"Department Name"); $pdf->cell(50,5, ":  ".$row2['typename'],0,1,"L"); 
    $pdf->cell(30,5,"Department Code");  $pdf->cell(50,5,":  ".$row2['typecode'],0,1,"L");

    // $pdf->cell(30,5,"Year Level");  $pdf->cell(50,5,":  ".$row2['yrlevel'],0,1,"L");
    // $pdf->cell(30,5,"E-mail"); $pdf->cell(50,5,":  ".$row2['email'],0,1,"L");
    // $pdf->cell(30,5,"Contact");  $pdf->cell(50,5,":  ".$row2['contact'],0,1,"L");
    // $pdf->cell(30,5,"Faculty"); $pdf->cell(50,5,":  ".$row2['Faculty'],0,1,"L");
    // $pdf->cell(30,5,"Department");  $pdf->cell(50,5,":  ".$row2['department'],0,1,"L"); //department
    // $pdf->cell(30,5,"Session");  $pdf->cell(50,5,":  ".$row2['session'],0,1,"L");
    // $pdf->cell(30,5,"Payment Status"); $pdf->cell(50,5,":  ".$row2['paymentconfirmMsg'],0,1,"L");
}
// print registered paid courses 
$pdf->Ln(15);
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'All paid registered Resit Courses',1,1,"C");
$pdf->SetFont('Arial','B',12);
$pdf->Cell(10,8,'No.',1,0,"C");
$pdf->Cell(35,8,'Student Number',1,0,"C");
$pdf->Cell(80,8,'Course Name',1,0,"C");
$pdf->Cell(30,8,'Course Code',1,0,"C");
$pdf->Cell(35,8,'Amount',1,0,"C");
// $pdf->Cell(45,8,'Student Number',1);
    // `tbtrialedcourses`(`id`, `stuNo`, `coursecode`, `coursename`, `yrtrialed`, `currentdate`, `payment`, `confirmedPayment
$yes = "Yes";
$query="SELECT * FROM tbtrialedcourses where confirmedPayment = '$yes'";
$result = mysqli_query($con, $query);
$no=0;
$totalpayment = 0;
while($row = mysqli_fetch_array($result)){
	$no=$no+1;
    $totalpayment += $row['payment']-5;
	$pdf->Ln(8);
	$pdf->SetFont('Arial','',12);
	$pdf->Cell(10,8,$no,1,0,"C");
	$pdf->Cell(35,8,$row['stuNo'],1);
	$pdf->Cell(80,8,$row['coursename'],1);
	$pdf->Cell(30,8,$row['coursecode'],1);
	$pdf->Cell(35,8,number_format($row['payment']-5,2),1);
	
}
$pdf->Ln(10);
$pdf->Cell(125,8," ",0);
// <?= number_format($row['payment'],2);
$pdf->Cell(65,8,"Total Amount = ".number_format($totalpayment,2),1);
// add admin details
$pdf->Ln(15);
$pdf->SetFont('Arial','',10);
$admin="1";
$query3="SELECT * FROM administor where id= '$admin'";
$result3 = mysqli_query($con, $query3);
if($result3) {
    $row3 = mysqli_fetch_assoc($result3);
    $pdf->Ln(11);

   $pdf->cell(50,5,".............................................",0,1,"L");
   $pdf->cell(50,5,$row3['name'],0,1,"C");
   $pdf->cell(50,5,"OFFICIALLY APPROVED BY:",0,1,"L");  
   $pdf->cell(50,5,"SRC,",0,1,"R");  
   $pdf->cell(50,5,"DEAN OF STUDENT,",0,1,"R");  
   $pdf->cell(50,5,"ALL DEPARTMENTAL HEADS",0,1,"R");  
   
   $pdf->Ln(5);
//   $pdf->line();

}


$pdf->Output('$stuNo_Resit_receipt','I');
?>