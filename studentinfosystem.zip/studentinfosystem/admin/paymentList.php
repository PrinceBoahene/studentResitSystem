<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Upturn Smart Online Exam System" />

</head> 
<body>
<div class="page-container">
   <!--/content-inner-->
<div class="left-content">
<div class="mother-grid-inner">
<?php 
session_start();

if($_SESSION["id"]==true)
{

 include("connect.php");
include("header.php"); ?>

	<ol class="breadcrumb">
	             <li class="breadcrumb-item text-white" ><h4 ><a href = "http://www.upturnit.com/product.php" onclick = "getConfirm(this.href);" class=" btn btn-primary hvr-icon-float-away col-9">Add Student </a></h4></li>
                <center><li class="breadcrumb-item"><h4><a href="">Payment List</a></h4></li></center>
            </ol>
<!--grid
 	<div class="validation-system">
 		
 		<div class="validation-form">
 	-->
  	    
<?php

include("connect.php");
$yes = "Yes";
$No = "No";
$sql = "SELECT  `id`,`stuNo`, `coursecode`, `coursename`, `yrtrialed`, `currentdate`, `payment`, `confirmedPayment` FROM `tbtrialedcourses`"; //WHERE confirmedPayment";
$sql2="SELECT payment from tbtrialedcourses WHERE confirmedPayment = '$yes' ";
$result = mysqli_query($con,$sql);
$result2 = mysqli_query($con,$sql2);
$payment_Made = 0;

while($rows2=mysqli_fetch_array($result2)){
$payment_Made += $rows2['payment'];
}
?>
<div class="agile-grids">
<div class="agile-tables">
<div class="w3l-table-info">
<a href="./printRegisteredCourses.php" class="btn btn-success btn-sm float-right "  target="_blank"><span class='glyphicon glyphicon-print'></span> Print all registered courses</a>
<h2>List of Registered courses </h2>

<table width="100%" id="table">
<thead>
<tr>
               <th align="left">No</th>
			   <th align="left">Student No.</th>
			   <th align="left">Course Code</th>
			   <th align="left">Course Name</th>
			   <th align="left">Year trailed</th>
			   <th align="left">Date Registered</th>
			   <th align="left">Amount</th>
			   <!-- <th align="left">Department</th>
			   <th align="left">Session</th> -->
			   <!-- <th align="left">Department</th> -->
			   <!-- <th align="left">Category</th>
			   <th align="left">File</th> -->
			   
			   <th align="left">Action</th>
			    
</tr>
</thead>
<tbody>
<?php $no = 0; $sum = 0; while($rows=mysqli_fetch_array($result))
{ $no +=1; 
	extract($rows);
    $sum += $rows['payment'];
	?>

<!-- // `students`(`id`, `password`, `studentno`, `firstname`, `lastname`, `course`, `yrlevel`, `date_joined`, -->
<!-- //  `email`, `indexNo`, `contact`, `Faculty`, `session` -->
    <tr>
    <td><?php echo $no; ?></td>
	<td><?php echo $rows['stuNo'];?></td>
    <td><?php echo $rows['coursecode'];?></td>
	<td><?php echo $rows['coursename'];?></td>
	<td><?php echo $rows['yrtrialed'];?></td>
	<td><?php echo $rows['currentdate'];?></td>
	<td><?php echo $rows['payment'];?></td>
 
	 
	<td>
	

    <?php
$status=$rows['confirmedPayment'];

if(($status)== $No)
{
?>
<button class="btn bg-danger">
<a href="./paymentaction.php?makepayment= <?= $rows['id']; ?>" onclick="return confirm('Are you sure you wish to confirm payment for this course?');"> Make Payment </a></button>
<?php
}
if(($status)== $yes)
{
?>
 <!-- //onclick = "getConfirm(this.href);" -->
<button class="btn bg-success ">
<a href="./paymentaction.php?cancel= <?= $rows['id']; ?>" onclick="return confirm('Are you sure you want to cancel payment for this course?');" > Cancel Payment</a></button><?php
}
?>

	</td>
    </tr>
<?php }?>
</tbody>
</table>

<legend class="text-center text-info"> Total Payment: GH&#8373; <?php echo number_format($sum,2)." &emsp;&emsp;&emsp; Payment Made: GH&#8373; ". number_format($payment_Made,2)."&emsp;&emsp;&emsp; Amount Due: GH&#8373; ". number_format($sum-$payment_Made,2);    ?></legend>
</div>
</div>
</div>
	
<?php include("footer.php"); ?>
</div></div>

	<?php include("sidebar.php"); ?>
	
	<?php }
else
	header('location:index.php');
?>
	</div>
</body>
<!--popup script start -->
<script type = "text/javascript">

function getConfirm(l)
{
  if(arguments[0] != null)
  {
    if(window.confirm('Get Full Source Code at reasonable cost  ' + l + '?\n'))
    {
      location.href = l;
    }
    
    else
    {
      event.cancelBubble = true;
      event.returnValue = false;
      return false;
    }
  }
  
  else
  {
    return false;
  }
  return;
}
</script>

	<!--popup script end -->
</html>