<?php
include("connect.php");

$depart = "Department";
$departments = 0;

$fac ="Faculty";
$faculty = 0;

$students = 0;

$yearlevel = "year";
$yrlevel = 0;

$session = "session";
$sesion = 0;

$course = 0;

$trailedcourse = 0;
$no_of_paid_course = 0;
$no_of_Unpaid_course = 0;
// students, stufacultydepart  stuyearnsessions  tbcourses  tbtrialedcourses
$sql = "SELECT * FROM stufacultydepart WHERE type= '$depart'";
$result = mysqli_query($con,$sql);

if (mysqli_num_rows($result) > 0) {
   
    while($row = mysqli_fetch_assoc($result)) {
     $departments++;
    }
} else {

}

$sql = "SELECT * FROM stufacultydepart WHERE type = '$fac'";
$result = mysqli_query($con,$sql);

if (mysqli_num_rows($result) > 0) {
   
    while($row = mysqli_fetch_assoc($result)) {
     $faculty++;
    }
} else {

}


$sql = "SELECT * FROM students";
$result = mysqli_query($con,$sql);

if (mysqli_num_rows($result) > 0) {
   
    while($row = mysqli_fetch_assoc($result)) {
     $students++;
    }
} else {

}

$sql = "SELECT * FROM stuyearnsessions WHERE type = '$yearlevel'";
$result = mysqli_query($con,$sql);

if (mysqli_num_rows($result)> 0) {
   
    while($row = mysqli_fetch_assoc($result)) {
     $yrlevel++;
    }
} else {

}

$sql = "SELECT * FROM stuyearnsessions WHERE type = '$session'";
$result = mysqli_query($con,$sql);

if (mysqli_num_rows($result) > 0) {
   
    while($row = mysqli_fetch_assoc($result)) {
     $sesion++;
    }
} else {

}


$sql = "SELECT * FROM tbcourses";
$result = mysqli_query($con,$sql);

if (mysqli_num_rows($result) > 0) {
   
    while($row = mysqli_fetch_assoc($result)) {
     $course++;
    }
} else {

}

$sql = "SELECT * FROM tbtrialedcourses";
$result = mysqli_query($con,$sql);

// (mysqli_num_rows($result) > 0) {
if (mysqli_num_rows($result) > 0) {
   
    while(mysqli_fetch_assoc($result)) {
     $trailedcourse++;
    }
} else {

}
$yes = "Yes";
$sql = "SELECT * FROM tbtrialedcourses WHERE confirmedPayment = '$yes'";
$result = mysqli_query($con,$sql);

if (mysqli_num_rows($result) > 0) {
   
    while($row = mysqli_fetch_assoc($result)) {
     $no_of_paid_course++;
    }
} else {

}

$No = "No";
$sql = "SELECT * FROM tbtrialedcourses WHERE confirmedPayment = '$No'";
$result = mysqli_query($con,$sql);

if (mysqli_num_rows($result) > 0) {
   
    while($row = mysqli_fetch_assoc($result)) {
     $no_of_Unpaid_course++;
    }
} else {

}

// $sql = "SELECT * FROM assesmenttbl";
// $result =  mysqli_query($con,$sql);

// if (mysqli_num_rows($result) > 0) {
   
//     while($row = mysqli_fetch_assoc($result)) {
//      $status = $row['status'];
// 	 if ($status == "PASS"){
// 		 $std_pass++;
// 	 }else{
// 		$std_fails++; 
		 
// 	 }
	 
//     }
// } else {

// }



mysqli_close($con);
?>