<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Online Resit Registration 
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Upturn Smart Online Exam System" />

</head> 
<body>
<div class="page-container">
   <!--/content-inner-->
<div class="left-content">
<div class="mother-grid-inner">
<?php 
session_start();

if($_SESSION["id"]==true)
{

 include("connect.php");
include("header.php");

if (isset($_GET['name'])) {
$keyword = ucwords($_GET['name']);	
$sql = "SELECT * FROM students WHERE firstname LIKE '%$keyword%' or lastname LIKE '%$keyword%' or studentno = '$keyword'";
}
 ?>

	<ol class="breadcrumb">
	             <li class="breadcrumb-item text-white" ><h4 ><a href="addstudent.php" class=" btn btn-primary hvr-icon-float-away col-9">Add Student </a></h4></li>
                <center><li class="breadcrumb-item"><h4><a href="">Student List</a></h4></li></center>
            </ol>
<!--grid
 	<div class="validation-system">
 		
 		<div class="validation-form">
 	-->
  	    
<?php

include("connect.php");
//$sql="select studid,fname,lname,gender,mobile,dob,address,deptname,catname,file,status from studenttbl ";
$result = mysqli_query($con,$sql);
?>
<div class="agile-grids">
<div class="agile-tables">
<div class="w3l-table-info">
<h2>List of Students</h2>
<table width="100%" id="table">
<thead>
<tr>
				<th align="left">No</th>
			   <th align="left">Name</th>
			   <th align="left">Student No.</th>
			   <th align="left">Index No.</th>
			   <th align="left">Year/Level</th>
			   <th align="left">Contact</th>
			   <th align="left">Faculty</th>
			   <th align="left">Department</th>
			   <th align="left">Session</th>
			   
			   <th align="left">Action</th>
			    
</tr>
</thead>
<tbody>
<?php $no=0; while($rows=mysqli_fetch_array($result))
{ $no +=1;
	extract($rows);
	?>

<tr>
    <td><?php echo $no; ?></td>
	<td><?php echo $rows['lastname']." ".$rows['firstname'];?></td>
    <td><?php echo $rows['studentno'];?></td>
	<td><?php echo $rows['indexNo'];?></td>
	<td><?php echo $rows['yrlevel'];?></td>
	<td><?php echo $rows['contact'];?></td>
	<td><?php echo $rows['Faculty'];?></td>
	<td><?php  echo $rows['department'];?></td>
	<td><?php echo $rows['session'];?></td>
	<td>
	

    <?php
$status=$rows['status'];
if(($status)=='0')
{
?>
<!-- <button class="btn bg-danger"> -->
<a href="studaction.php?status_activate=<?php echo $rows['studentno'];?>" 
  onclick="return confirm('Activate <?php echo $rows['firstname'];?>');"> <span class='glyphicon glyphicon-remove'> </span> </a>
<!-- </button> -->
<?php
}
if(($status)=='1')
{
?>
<!-- <button class="btn bg-success text-white "> -->
<a href="studaction.php?status_activate=<?php echo $rows['studentno'];?>" 
 onclick="return confirm('In-activate <?php echo $rows['firstname'];?>');"> <span class='glyphicon glyphicon-ok'> </span></a>
 <!-- </button> -->
 <?php
}
?>

	<!-- <button class="btn btn-dark text-white "> -->
		<a href="studaction.php?status_del=<?php echo $rows['studentno']; ?>" 
    onclick="return confirm('Are you sure you wish to delete this Record?');"><span class='glyphicon glyphicon-trash'> </span> </a> 
<!-- </button> -->
 
	<!-- <button class="btn bg-alert dark text-white "> -->
		<a href="editstudent.php?id=<?php echo $rows['studentno']; ?>"> <span class='glyphicon glyphicon-edit'> </span> </a>
	<!-- </button> -->
	</td>
    </tr>
<?php }?>
</tbody>
</table>
</div>
</div>
</div>
	
<?php include("footer.php"); ?>
</div></div>

	<?php include("sidebar.php"); ?>
	
	<?php }
else
	header('location:index.php');
?>
	</div>
</body>
</html>