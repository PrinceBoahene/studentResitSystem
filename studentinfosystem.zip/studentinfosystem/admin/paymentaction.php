<?php
include('connect.php');

// make payment 
if(isset($_GET['makepayment']))
{
$trailRegId=$_GET['makepayment'];
$payment_status = "Yes";
$_SESSION['id'] = $_GET['makepayment'];
// SELECT `id`, `stuNo`, `coursecode`, `coursename`, `yrtrialed`, `currentdate`
// , `payment`, `confirmedPayment` FROM `tbtrialedcourses` WHERE 1
$update=mysqli_query($con,"UPDATE tbtrialedcourses set confirmedPayment='$payment_status' where id='$trailRegId' ");
if($update)
{
    updatepayInfo(); //update payment status in the student table
header("Location: ./paymentlist.php");
} 
else
{
echo mysqli_connect_error();
}

?>
<?php
}

// cancel payment
if(isset($_GET['cancel']))
{
$trailRegId=$_GET['cancel'];
$payment_status = "No";
$_SESSION['id'] = $_GET['cancel'];

// SELECT `id`, `stuNo`, `coursecode`, `coursename`, `yrtrialed`, `currentdate`
// , `payment`, `confirmedPayment` FROM `tbtrialedcourses` WHERE 1
$update=mysqli_query($con,"UPDATE tbtrialedcourses set confirmedPayment='$payment_status' where id='$trailRegId' ");
if($update)
{
    updatepayInfo(); //update payment status in the student table
header("Location: ./paymentlist.php");
} 
else
{
echo mysqli_connect_error();
}

?>
<?php
}


function updatepayInfo(){
    include './connect.php';
    $confirmYESNO = "Yes";
    $confirmNO = "No";
  
    // $stuNo = $_SESSION['studentno'];
    $query7 = "SELECT stuNo from tbtrialedcourses WHERE id =". $_SESSION['id'];
    $stmt = $con->prepare($query7);
    $stmt->execute();
    $result7 = $stmt->get_result();
    $row7 = $result7->fetch_assoc();
    $stuN = $row7['stuNo']; //getting the student number from student table

    $query5="SELECT * FROM tbtrialedcourses WHERE stuNo = '$stuN' AND confirmedPayment = '$confirmYESNO'"; //get paid ones
    $query6="SELECT * FROM tbtrialedcourses WHERE stuNo = '$stuN' AND confirmedPayment = '$confirmNO'";  //get unpaid ones
    // $result5 = mysqli_query($con, $query5);
    // $result6 = mysqli_query($con, $query6);
    $stmt = $con->prepare($query5);
    $stmt->execute();
    $result5 = $stmt->get_result();

    $stmt = $con->prepare($query6);
    $stmt->execute();
    $result6 = $stmt->get_result();

    $paid_Counter = 0;
    $Num_of_all_registered_courses = 0;
    $amountpaidy = 0;
    // for($i=0;$i<=$result5-.mysqli_fetch_assoc();$i++){
    //     $i  
    // }
    while ($row5 = $result5->fetch_assoc()) {
            $paid_Counter += 1;
    }
    while ($row6 = $result6->fetch_assoc()) {
        $Num_of_all_registered_courses += 1;
        $amountpaidy = $row6['payment'];
}

if($paid_Counter == ($paid_Counter + $Num_of_all_registered_courses))
$payMsg = "Full payment";
else
  $payMsg = "Payment of ".$paid_Counter." out of ". ($paid_Counter + $Num_of_all_registered_courses)." registered courses";


    $query="UPDATE students SET paymentconfirmMsg=? WHERE studentno=$stuN";
    $stmt=$con->prepare($query);
    $stmt->bind_param("s",$payMsg);
    $stmt->execute();



}
?>