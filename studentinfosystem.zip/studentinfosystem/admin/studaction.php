<?php
ob_start();
include('connect.php');
// activation
if(isset($_GET['status_activate'])){
    $status2=$_GET['status_activate'];
    $select=mysqli_query($con,"SELECT * from students where studentno='$status2'");
    while($row=mysqli_fetch_array($select)){
        $status_var=$row['status'];
        if($status_var=='0'){
             $status_state=1;
         }
        else{
     $status_state=0;
    }

    $update=mysqli_query($con,"UPDATE students set status='$status_state' where studentno='$status2' ");
    if($update)
    {
        // comment
    header("Location: ./studentlist.php");
    }
    else
    {
    echo mysqli_connect_error();
    }
    }
    ?>
    <?php
    }
    // delete
    elseif(isset($_GET['status_del'])){
        $stuno = $_GET['status_del'];
        $query = mysqli_query($con,"DELETE FROM students where studentno='$stuno'");
        if($query){
            // comment
            header("Location: ./studentlist.php");
        }else{
            // comment
            header("Location: ./studentlist.php");
        }

    }

    //edit

    else
    echo "Error loading page...";

    ob_end_flush();
    ?>
