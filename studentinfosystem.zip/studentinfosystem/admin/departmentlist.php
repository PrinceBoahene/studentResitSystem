<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Upturn Smart Online Exam System" />

</head> 
<body>
<div class="page-container">
   <!--/content-inner-->
<div class="left-content">
<div class="mother-grid-inner">
<?php 
session_start();
if($_SESSION["id"]==true)
{

include("header.php"); ?>

	<ol class="breadcrumb">
                <center><li class="breadcrumb-item"><h4><a href="">Department List</a></h4></li></center>
            </ol>
<!--grid 
 	<div class="validation-system">
 		
 		<div class="validation-form">
 	<!---->
	
<?php
		//    `stufacultydepart`(`id`, `typename`, `type`, `typecode`)

include("connect.php");
$type = 'department';
$sql="select id,typename,typecode, status from stufacultydepart WHERE type= '$type'";
$result = mysqli_query($con,$sql);
?>
<div class="agile-grids">
<div class="agile-tables">
<div class="w3l-table-info">
<h2>Departments</h2>
<table width="100%" id="table">
<thead>
<tr>
               <th align="left">Id</th>
			   <th align="left">Department Name</th>
         <th align="left">Department Code</th>
			   <th align="left">Action</th>
			    
</tr>
</thead>
<tbody>
<?php $no=0; while($rows=mysqli_fetch_array($result))
{ $no +=1;
	?>

    <tr>
    <td><?php echo $no; ?></td> <!-- $no;  -->
    <td><?php echo $rows['typename'];?></td>
    <td><?php echo $rows['typecode'];?></td>
	
	<td>
    <?php
	$status=$rows['status'];
if(($status)=='0')
{
?>
<!-- <button class="btn bg-danger"> -->
<a   href = "#" onclick = "getConfirm(this.href);" > <span class='glyphicon glyphicon-remove'>  </a>
<!-- </button> -->
<?php
}
if(($status)=='1')
{
?>
<!-- <button class="btn bg-success"> -->
<a   href = "#" onclick = "getConfirm(this.href);" > <span class='glyphicon glyphicon-ok'> </a>
<!-- </button> -->
<?php
}
?>

	<!-- <button class="btn btn-dark"> -->
    <a href = "./editdepartment.php?delete=<?php echo $rows['id']; ?>"  onclick = "return confirm('Do you want to Delete')"><span class='glyphicon glyphicon-trash'>  </a> 
  <!-- </button> -->
 
	<!-- <button class="btn bg-alert dark text-white "> -->
    <a href = "./editdepartment.php?id=<?php echo $rows['id']; ?>"  onclick = "return confirm('Do you want to Edit ')"> <span class='glyphicon glyphicon-edit'>  </a>
  <!-- </button> -->
	</td>
    </tr>
<?php }?>
</tbody>
</table>
</div>
</div>
</div>

<!--<button><a href="logout.php">Logout</a></button>-->

<!--
 </div>

</div>
 	<!--//grid-->
	
<?php include("footer.php"); ?>
</div></div>


	
	<?php include("sidebar.php"); ?>
	<?php }
else
	header('location:index.php');
?>
	</div>
</body>











<!--popup script start -->
<!-- <script type = "text/javascript">

function getConfirm(l)
{
  if(arguments[0] != null)
  {
    if(window.confirm('Get Full Source Code at reasonable cost  ' + l + '?\n'))
    {
      location.href = l;
    }
    
    else
    {
      event.cancelBubble = true;
      event.returnValue = false;
      return false;
    }
  }
  
  else
  {
    return false;
  }
  return;
}
</script> -->

	<!--popup script end -->
</html>
<?php

mysqli_close($con);
?>
