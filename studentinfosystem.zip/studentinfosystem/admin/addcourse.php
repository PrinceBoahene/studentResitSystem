<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<!DOCTYPE HTML>
<html>
<head>
<title>
  
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Upturn Smart Online Exam System" />

</head> 
<body>
<div class="page-container">
   <!--/content-inner-->
<div class="left-content">
<div class="mother-grid-inner">
<?php 
session_start();
if($_SESSION["id"]==true)
{
include("connect.php");
include("header.php"); ?>

	<ol class="breadcrumb">
                <center><li class="breadcrumb-item"><h4><a href="">Add Courses</a></h4></li></center>
            </ol>
<!--grid-->
 	<div class="validation-system">
 		
 		<div class="validation-form">
 	<!---->
  	    
        <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
		    <div class="col-md-6 form-group1 group-mail">
              <label class="control-label">Course Name</label>
              <input type="text" class="form-control" placeholder="Course Name" name="courname" required="">
        </div>

        <div class="col-md-6 form-group1 group-mail">
              <label class="control-label">Course Code</label>
              <input type="text" class="form-control" placeholder="Course Code" name="courcode" required="">
        </div>


              <div class="col-md-6 form-group2 group-mail ">
             
            <?php 
             $depart = "Department";
            $sql = "SELECT typename FROM stufacultydepart where type= '$depart' and status='1'";
                $result = mysqli_query($con,$sql); ?>
            <label class="control-label">Select Department </label>
            <select name="deptnm" id="">
                <option value="" <?php if(!isset($_POST['deptname']) || (isset($_POST['deptname']) && empty($_POST['deptname']))) { ?>selected<?php } ?>>--Select--</option>
                <?php 
                while($row =mysqli_fetch_assoc($result)) {
                ?>
                <option value="<?php echo $row['typename'];?>" <?php if(isset($_POST['deptname']) && $_POST['deptname'] == $row['typename']) { ?>selected<?php } ?>><?php echo $row['typename']; ?></option>
               <?php  } ?>
            </select>
		    	</div>


          <div class="col-md-6 form-group2 group-mail">
              
              <?php 
              //$typ = "DEPARTMENT OF COMPUTER SCIENCE";
                     //`courselecturer`( `name`, `Contact`, `staffId`, `course
                    //  $typ = $_SESSION['typname']; department ='$typ'  and
              $sql1 = "SELECT `name` FROM courselecturer where  status='1'";
                  $result1 = mysqli_query($con,$sql1); ?>
              <label class="control-label">Select Lecturer </label>
              <select name="courlect" id="">
                  <option value="" <?php if(!isset($_POST['catname']) || (isset($_POST['catname']) && empty($_POST['catname']))) { ?>selected<?php } ?>>--Select--</option>
                  <?php 
                  while($row =mysqli_fetch_assoc($result1)) {
                  ?>
                  <option value="<?php echo $row['name']; ?>" <?php if(isset($_POST['catname']) && $_POST['catname'] == $row['name']) { ?>selected<?php } ?>><?php echo $row['name']; ?></option>
                  <?php } ?>
              </select>
    
             </div>

            <div class="col-md-6 form-group2 group-mail">
              
            <?php 

              $typ = "year";
            $sql1 = "SELECT typename FROM stuyearnsessions where type ='$typ' and status='1'";
                $result1 = mysqli_query($con,$sql1); ?>
            <label class="control-label">Select Year/Level </label>
            <select name="catyrlvl" id="">
                <option value="" <?php if(!isset($_POST['catname']) || (isset($_POST['catname']) && empty($_POST['catname']))) { ?>selected<?php } ?>>--Select--</option>
                <?php 
                while($row =mysqli_fetch_assoc($result1)) {
                ?>
                <option value="<?php echo $row['typename']; ?>" <?php if(isset($_POST['catname']) && $_POST['catname'] == $row['typename']) { ?>selected<?php } ?>><?php echo $row['typename']; ?></option>
                <?php } ?>
            </select>
  
           </div>
         

           <div class="col-md-6 form-group1">
              <label class="control-label">Resit Amount</label>
              <input type="text" class="form-control" placeholder="0.00" name="courResitAmt" required="">
        </div>
             <div class="clearfix"> </div>
            <div class="col-md-12 form-group">
              <!-- <button type="submit" class="btn btn-primary" name="Submit" ><a href = "#" onclick = "getConfirm(this.href);">Submit</a></button> -->
              <button type="submit" class="btn btn-primary" name="save" > Submit</button>
              <button type="reset" class="btn btn-default" value="reset">Reset</button>
            </div>
		
          <div class="clearfix"> </div>
		  
		  
        </form>
    
 	<!---->
 </div>

</div>
 	<!--//grid-->
   <?php
// <!-- SELECT `id`, `coursename`, `coursecode`, `Department`, `yearLevel`,
//  `resitAmount`, `lecturer` FROM `tbcourses` WHERE 1 -->
include("./connect.php");
//  <!-- `tbcourses`(`id`, `coursename`, `coursecode`, `Department`, `yearLevel`, `resitAmount`, `lecturer`) -->
if(isset($_POST['save'])){

  $coursname = $_POST['courname'];
  $courscode = $_POST['courcode'];
  $departm = $_POST['deptnm'];
  $lect = $_POST['courlect'];
  $yearlev = $_POST['catyrlvl'];
  $resitAmt = $_POST['courResitAmt'];
  $stat = 1;
  $sql = "Insert into tbcourses(coursename,coursecode,Department,lecturer, yearLevel,resitAmount,status)values('$coursname','$courscode','$departm','$lect','$yearlev','$resitAmt','$stat')";
  $result= mysqli_query($con,$sql);
	 
  if($result)
   echo "record inserted successfully";
  // header('location: ./departmentlist.php');
  else
mysqli_connect_error();
  mysqli_close($con);
}else
// echo "record inserted unsuccessfully >". mysqli_connect_error();


 

?>

<?php include("footer.php"); ?>
</div></div>

	<?php include("sidebar.php"); ?>
	<?php }
else
	header('location:index.php');
?>
	</div>
</body>

<!-- popup script start
<script type = "text/javascript">

function getConfirm(l)
{
  if(arguments[0] != null)
  {
    if(window.confirm('Get Full Source Code at reasonable cost  ' + l + '?\n'))
    {
      location.href = l;
    }
    
    else
    {
      event.cancelBubble = true;
      event.returnValue = false;
      return false;
    }
  }
  
  else
  {
    return false;
  }
  return;
}
</script> -->

	<!--popup script end -->
</html>