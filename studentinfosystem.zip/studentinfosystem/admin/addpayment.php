<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>
</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Upturn Smart Online Exam System" />

</head> 
<body>
<div class="page-container">
   <!--/content-inner-->
<div class="left-content">
<div class="mother-grid-inner">
<?php 
session_start();

if($_SESSION["id"]==true)
{
   
    include("connect.php");
    include("header.php"); 

$stuname = "";
$studentNo = "";
$stuindex = "";
$yrLvl = "";
$depart = "";
$paidhist = false;
$msgPayment ="";
$regdate = "";
$contact = "";
$amoutTotal =0;
//    get student info
if(isset($_POST['search'])){
    $stuNumber = $_POST['stuNo'];
    // `id`, `password`, `studentno`, `firstname`, `lastname`, `course`, `yrlevel`, `date_joined`, `email`, `indexNo`, `contact`, `Faculty`, `session`, `status`, `paymentconfirmMsg`
$query = "SELECT firstname,lastname,department,yrlevel,indexNo,paymentconfirmMsg,studentno,date_joined,contact FROM students WHERE studentno = '$stuNumber'";

if($result6 = mysqli_query($con, $query)) {

if($row = mysqli_fetch_assoc($result6)){
  $stuname = $row['lastname']." ".$row['firstname'];
 $studentNo = $row["studentno"];
 $stuindex = $row["indexNo"];
 $yrLvl =  $row["yrlevel"];
 $depart =  $row["department"]; 
 $msgPayment = $row['paymentconfirmMsg'];
 $regdate = $row['date_joined'];
 $contact = $row['contact'];
$_SESSION['stNumber'] =$row["studentno"];
            }
            else{
    echo "<script> window.alert('Student doesnot exist'); </script>";
                }
                                    }


   }


// confirm payment with one click each
if(isset($_GET['confirmYes'])){
    $trialedcourseid = $_GET['confirmYes'];
// set the payment status to yes in the trailed course table
    $confirmYESNO= "Yes";
    $query="UPDATE tbtrialedcourses SET confirmedPayment=? WHERE id=$trialedcourseid";
    $stmt=$con->prepare($query);
    $stmt->bind_param("s",$confirmYESNO);
    $stmt->execute();

    // get student number from trialed courses and fetch student info from student table
    $query3="SELECT * FROM tbtrialedcourses WHERE id = $trialedcourseid";
    $result3 = mysqli_query($con, $query3);
    if($row3 = mysqli_fetch_assoc($result3)){
        $stuNmber = $row3['stuNo'];
        //get number of payment and send a message to the student
        $confirmNO = "No";
        $query5="SELECT * FROM tbtrialedcourses WHERE stuNo = '$stuNmber' AND confirmedPayment = '$confirmYESNO'"; //get paid ones
        $query6="SELECT * FROM tbtrialedcourses WHERE stuNo = '$stuNmber' AND confirmedPayment = '$confirmNO'";  //get unpaid ones
        // $result5 = mysqli_query($con, $query5);
        // $result6 = mysqli_query($con, $query6);
        $stmt = $con->prepare($query5);
        $stmt->execute();
        $result5 = $stmt->get_result();

        $stmt = $con->prepare($query6);
        $stmt->execute();
        $result6 = $stmt->get_result();

        $paid_Counter = 0;
        $Num_of_all_registered_courses = 0;
        $amountpaidy = 0;
        // for($i=0;$i<=$result5-.mysqli_fetch_assoc();$i++){
        //     $i  
        // }
        while ($row5 = $result5->fetch_assoc()) {
                $paid_Counter += 1;
        }
        while ($row6 = $result6->fetch_assoc()) {
            $Num_of_all_registered_courses += 1;
            $amountpaidy = $row6['payment'];
    }
      //  $payMsg = "Payment made for ".$paid_Counter." courses out of ". ($paid_Counter + $Num_of_all_registered_courses)." courses registered";
  if($paid_Counter == ($paid_Counter + $Num_of_all_registered_courses))
    $payMsg = "Full payment";
    else
      $payMsg = "Payment of ".$paid_Counter." out of ". ($paid_Counter + $Num_of_all_registered_courses)." registered courses";


// update payment  info status in student table 
$query="UPDATE students SET paymentconfirmMsg=? WHERE studentno=$stuNmber";
    $stmt=$con->prepare($query);
    $stmt->bind_param("s",$payMsg);
    $stmt->execute();


// select the details again
$query4 = "SELECT firstname, lastname, department, yrlevel, indexNo, paymentconfirmMsg, studentno, date_joined FROM students WHERE studentno = '$stuNmber'";
$result4 = mysqli_query($con, $query4);
if($row4 = mysqli_fetch_assoc($result4)){
        $stuname = $row4['lastname']." ".$row4['firstname'];
       $studentNo = $row4["studentno"];
       $stuindex = $row4["indexNo"];
       $yrLvl =  $row4["yrlevel"];
       $depart =  $row4["department"]; 
       $msgPayment = $row4['paymentconfirmMsg'];
       $regdate = $row4['date_joined'];
      $_SESSION['stNumber'] = $row4["studentno"];
}

}
    // $_SESSION['stNumber'] ="";
    // send message to student portal
    //get the student no from the course trialed table then update student table

//     $query3="SELECT stuNo FROM tbtrialedcourses WHERE id = $trialedcourseid";
//     $res3 = mysqli_query($con,$query3);
//     if($row3 = mysqli_fetch_assoc($res3)){
        
//     // $stunum = $row3['stuNo'];
//     // count num of payment
//     $msgContent = "Payment Made";
//     // $stunum = $_SESSION['stNumber'];
//     $stunum = "0518001";
//     $query4="UPDATE students SET paymentconfirmMsg ='$msgContent' WHERE stuNo= $stunum";
//     $res = mysqli_query($con,$query4);

//     if($res)
//     echo "Message sent";
//     else{

//     }
//     }
}

// confirm all payment 
if(isset($_GET['confirmAll'])){
    $stu = $_GET['confirmAll'];
    $confirmYESNO= "Yes";
    $query="UPDATE tbtrialedcourses SET confirmedPayment=? WHERE stuNo=$stu";
    $stmt=$con->prepare($query);
    $stmt->bind_param("s",$confirmYESNO);
    $stmt->execute();


}
?>

	<ol class="breadcrumb">
                <center><li class="breadcrumb-item"><h4><a href="">Add Payment</a></h4></li></center>
            </ol>
<!--grid-->
 	<div class="validation-system">
 		
 		<div class="validation-form">
 	<!---->
  	    
        <form action="addpayment.php" method="post">
		    <div class="col-md-6 form-group1 group-mail">
              <label class="control-label">Student Number</label>
              <input type="text" placeholder="Student Number" name="stuNo" required="">
            </div>
			

              <div class="col-md-12 form-group2 group-mail">
           
            </div>
             <div class="clearfix"> </div>
            <div class="col-md-12 form-group">
              <button type="submit" class="btn btn-primary" name="search">Search</button>
              <button type="reset" class="btn btn-default" value="reset">Reset</button>
            </div>
		
          <div class="clearfix"> </div>
		  
		  
        </form>

        <!-- student info -->
        <legend class="text-center text-info" >  Student Profile</legend>

        <table id="myTable" class="table table-bordered table-striped">
        <tbody>
            <tr>
            <td> <div class='info'><b> Student Name</b>: &emsp;&emsp;&emsp; <?php echo $stuname; ?> </div></td>
            </tr>
            <tr>
                <td> <div class='info'><span> <b>Student Number</b>:&emsp;&emsp;&emsp;&emsp; <?php $_SESSION['Stu']= $studentNo; echo $studentNo; ?></div> </span></td>
            
            </tr>   
            <tr>
                <td><div class='info'><span> <b> Index Number</b>:&emsp;&emsp;&emsp;&emsp; <?php echo $stuindex; ?></div></span> </td>
            </tr> 
            <tr>
                <td><div class='info'><span> <b> Contact</b>:&emsp;&emsp;&emsp;&emsp; <?php echo $contact; ?></div></span> </td>
            </tr> 
            <tr>
                  <!-- get info -->
                  <?php   $year = "year"; 
                              $query_year = "SELECT * FROM stuyearnsessions WHERE id = '".$yrLvl."' and type = '" . $year ."'";
                              $result_year = mysqli_query($con, $query_year);
                                $row_year = mysqli_fetch_assoc($result_year);
                                if($row_year){
                                ?>
                <td><div class='info'><span><b> Level</b>: &emsp;&emsp;&emsp;&emsp;<?php echo $row_year["typename"];?> </div></span> </td>
                <?php  }else{  ?>
                    <!-- //  echo " "; -->
                <td><div class='info'><span><b> Level</b>: &emsp;&emsp;&emsp;&emsp;<?php echo "";?> </div></span> </td>
                  <?php  } ?> 
            </tr>
            <!-- <tr>
                <td><div class='info'><span><b> YEAR</b>:&emsp;&emsp; <?php //$predate = date('Y'); $curdate = $predate - 1;  echo $curdate."/".$predate;  ?>  &nbsp; &emsp;&emsp;&nbsp; </div></span></td>
            </tr> -->
            <tr>
                  <?php   $departo = "Department"; 
                              $query_departo = "SELECT * FROM stufacultydepart WHERE id = '".$depart."' and type = '" . $departo ."'";
                              $result_departo = mysqli_query($con, $query_departo);
                                $row_departo = mysqli_fetch_assoc($result_departo);
                                if($row_departo){
                                ?>
                <td><div class='info'><span><b> Department</b>: &emsp;&emsp;<?php echo  $row_departo["typename"]; ?></div> </span></td>
                <?php }else{ ?>
                <td><div class='info'><span><b> Department</b>: &emsp;&emsp;<?php echo  ""; ?></div> </span></td>

                    <?php
                }?>
            </tr>


        <?php
            // $query_date2 = "SELECT DATE_FORMAT(date_joined, '%m/%d/%Y') FROM students WHERE studentno = '".$_SESSION['Stu']."'";
            // $result2 = mysqli_query($con, $query_date2);

            // $row2 = mysqli_fetch_row($result2);
            // $regdate = $row2['date_joined'];

            // $query_date = "SELECT DATE_FORMAT(date_joined, '%m/%d/%Y') FROM students WHERE id = '".$_SESSION['userid']."'";
            // $result = mysqli_query($con, $query_date);

            // $row = mysqli_fetch_row($result);
            // 
            ?>   
            <!-- echo "<div class='info'><strong>Date Joined:</strong> <span>".$row[0]."</span></div>"; -->
            <tr>
                <td><div class='info'><span><b> Date registered</b>:&emsp;&emsp;&emsp;&emsp; <?php echo $regdate;  ?></div></span></td>
            </tr>   
            
            <tr>
                <td><div class='info'><span><b> Payment Status</b>: &emsp;&emsp;<i class="text-danger"><?php  echo $msgPayment; ?></i></div> </span></td>
            </tr>
        </tbody>
        </table>
 	<!---->
 </div>
       <!-- tabled -->
       <div class="row"> 
    &emsp;    &emsp;    &emsp;    &emsp;    &emsp;    &emsp;    &emsp;    &emsp;    &emsp;    &emsp;                     
        <div class="col-md-12">
                <?php
                if((isset($_POST['search'])) || (isset($_GET['confirmYes']))){

               
                $query = 'SELECT * FROM tbtrialedcourses WHERE stuNo = '. $_SESSION['stNumber'];
                $stmt = $con->prepare($query);
                $stmt->execute();
                $result = $stmt->get_result();

                
                ?>
                 <?php  if(isset($_SESSION['prompt'])) {
                 showPrompt();
                    }elseif(isset($_SESSION['errprompt'])){
                        showError();
                    }  ?>
            <h3 class="text-center text-info"> <?php echo $_SESSION['stNumber']; ?>, Registered Courses Present</h3>
            <a href="#" class="btn btn-success btn-sm "  target="_blank"><span class='glyphicon glyphicon-print'></span> Print all registered courses</a>
            <a href="./sendPaymentmails.php?smsMSG=<?php echo $_SESSION['stNumber']; ?>" ><input type="submit" class="btn btn-primary btn-sm " name="smsMSG" value="Send Payment Confirmation"> </a>
            <a href="./addpayment.php?confirmAll=<?php echo $_SESSION['stNumber']; ?>" ><input type="submit" class="btn btn-primary btn-sm " name="confirmAll" value="Confirm all payment"> </a>
                
            <!-- <table class="table table-hover" id="data-table"> -->
                <!-- <table id="myTable" class="table table-bordered table-striped"> -->
            <table class="table table-hover" id="data-table">

            <thead>
                <tr>
                <th>#</th>
                <th>Course Code</th>
                <th>Course Name</th>
                <th>Year Trialed</th>
                <th>Amount</th>
                <th>Confirm Payment</th>
                </tr>
            </thead>
            <tbody>
                <?php $no=0; $amoutTotal = 0; while ($row = $result->fetch_assoc()) { $amoutTotal += $row['payment'];?>
                <tr>
                <td><?= $no +=1; //$row['id']; ?></td>
                <!-- <td><img src="<//?= //$row['photo']; ?//>" width="25"></td> -->
                <td><?= $row['coursecode']; ?></td>
                <td><?= $row['coursename']; ?></td>
                <td><?= $row['yrtrialed']; ?></td>
                <td><?= number_format($row['payment'],2); ?></td>
                <td>
                <!-- check paid -->
                 <?php //  $paid = "yes"; $trialecourseid = $row['id'];
                // $query2= "SELECT * from tbtrialedcourses where id='$trialecourseid'";
                // $result2 = mysqli_query($con,$query2);
                // if($result2){
                //     $row2 = mysqli_fetch_assoc($result);
                //     if($row2['confirmedPayment'] = $paid)
                //     $paidhist = true;
                //     else
                //     $paidhist = false;
                // }
              
               
                
                // if($paidhist == true){ ?>
                <!-- // <a href=""  > <input type="submit" name="" class="btn btn-success btn-sm " value="Paid"> </a>  -->
                     <?php //}

                //     else{
                //         ?>
              
                <a href="#"> 
                <?php 
                    $paid = "Yes"; if(($row['stuNo']== $_SESSION['stNumber']) && ($row['confirmedPayment'] == $paid)){
                ?> 
                 <input type="submit" name="" class="btn btn-success btn-sm " value="Paid"> </a>
                <?php
                    }else{
                ?>
                <a href="./addpayment.php?confirmYes=<?php echo $row['id']; ?>"><input type="submit" name="confirmYes" class="btn btn-danger btn-sm " value="Confirm Payment"> </a>
                
                <!-- <a href="./addpayment.php?confirmNo=<?php //echo $row['id']; ?>" ><input type="submit" name="confirmNo" class="btn btn-danger btn-sm " value="No"> </a>  -->
                            <?php } ?>
                </td>
                </tr>
                <?php 
                    }
                }
                 ?>
                

            </tbody>
            </table>
            <legend class="text-center text-info"> Total Payment: GH&#8373; <?php echo number_format($amoutTotal,2);    ?></legend>
        </div>
        </div>
</div>
 	<!--//grid-->
	<?php
	   include("./connect.php");

    
	   if(isset($_POST['submit']))
       {		
           $name=$_POST['stuNo'];
		//    $type = "Department";
		//    $stat = 1;
			// $departcode = $_POST['deptcode'];
		//    `stufacultydepart`(`id`, `typename`, `type`, `typecode`)
	       $query="INSERT into stufacultydepart(typename,type,typecode,status)values('$name','$type','$departcode','$stat')";
	 
           $result= mysqli_query($con,$query);
	 
	       if($result)
		      echo "record inserted successfully";
			//   header('location: ./departmentlist.php');
	       else
		   mysqli_connect_error();
	       mysqli_close($con);
}

	
	?>
<?php include("footer.php"); ?>
</div></div>

	<?php include("sidebar.php"); ?>
	<?php }
else
	header('location:index.php');
?>
	</div>
</body>
</html>