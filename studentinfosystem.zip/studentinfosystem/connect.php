<?php 

	$host = "localhost";
	$username = "root";
	$password = "";
	$db_name = "studentinfosystem";

	$con = mysqli_connect($host, $username, $password, $db_name);

	// if(!$con) {
	// 	die("Cannot connect to the database");
	// }

	
	// $host = "192.168.30.23";
	// $username = "root@192.168.30.20";
	// $password = "";
	// $db_name = "studentinfosystem";

	// $con = mysqli_connect($host, $username, $password, $db_name);

	// if(!$con) {
	// 	die("Cannot connect to the database");
	// }
?>