<?php 

  session_start();

  require 'connect.php';
  require './functions.php';
// $depart = $_SESSION['department'];

  $update=false;
  $id="";
  $coursename="";
  $coursecode="";
  $yeartrailed="";
  $amount= 55;
  $stuNo = $_SESSION['studentno'];
//   add new courses
  if(isset($_POST['add'])){
    // `tbtrialedcourses`(`id`, `stuNo`, `coursecode`, `coursename`, `yrtrialed`, `currentdate`, `payment`, `confirmedPayment
    $coursename=$_POST['coursename'];
    $coursecode=$_POST['coursecode'];
    $yeartrailed=$_POST['yrtrailed'];
    // $indexnumber = $_POST['indexNo'];
    $amount=$_POST['amount'];
    $curdate = date("y-m-d");
    $paid = "No";
    $query="INSERT INTO tbtrialedcourses(stuNo,coursecode,coursename,yrtrialed,currentdate,payment,confirmedPayment)
    VALUES(?,?,?,?,?,?,?)";
$stmt=$con->prepare($query);
$stmt->bind_param("sssssss",$stuNo,$coursecode,$coursename,$yeartrailed,$curdate,$amount,$paid);
$stmt->execute();
// move_uploaded_file($_FILES['image']['tmp_name'], $upload);
// $update=false;
$_SESSION['prompt'] = "Registraton course ($coursename) successful.";

updatepayInfo();

header('location: ./courseregistration.php');

}
// edit portal
if(isset($_GET['edit'])){
    $id=$_GET['edit'];
//    $id= $_SESSION['studentno'];
    $query="SELECT * FROM tbtrialedcourses WHERE id=?";
    $stmt=$con->prepare($query);
    $stmt->bind_param("i",$id);
    $stmt->execute();
    $result=$stmt->get_result();
    $row=$result->fetch_assoc();

    $id=$row['id'];
    $coursecode=$row['coursecode'];
    $coursename=$row['coursename'];
    $yeartrailed=$row['yrtrialed'];
    $amount = $row['payment'];

    // $photo=$row['photo'];
    // `stuNo``coursecode``coursename``yrtrialed``currentdate``payment``confirmedPayment`
    $update=true;
}

// update for course trialed
if(isset($_POST['update'])){
    $id= $_POST['id']; 

    // $id= $_SESSION['studentno'];
    $ccode=$_POST['coursecode'];
    $cname=$_POST['coursename'];
    $ytrailed=$_POST['yrtrailed'];
    $amt = $_POST['amount'];
    $cudate = date("y-m-d");
    // echo "<script> window.alert('GOO $id') </script>";
    $query="UPDATE tbtrialedcourses SET coursecode=?,coursename=?,yrtrialed=?,currentdate=?,payment=? WHERE id=$id";
    $stmt=$con->prepare($query);
    $stmt->bind_param("sssss",$ccode,$cname,$ytrailed,$cudate,$amt);
    // $stmt->bind_param("ssssss",'CSH 300','African Studies','2021','2020-01-04', '30','30');
    $stmt->execute();
    $update= false;
    $_SESSION['prompt'] = "Registered Course Updated";
}

if(isset($_GET['delete'])){
    $id= $_GET['delete'];
    // $amount = $id;
    
   $stu =  $_SESSION['studentno'];
    // $sql= "SELECT * FROM tbtrialedcourses WHERE id=?";
    // $stmt2=$conn->prepare($sql);
    // $stmt2->bind_param("i",$id);
    // $stmt2->execute();
    // $result2=$stmt2->get_result();
    // $row=$result2->fetch_assoc();

    $query="DELETE FROM tbtrialedcourses WHERE id=? and stuNo=?";
    $stmt=$con->prepare($query);
    $stmt->bind_param("is",$id,$stu);
    $stmt->execute();
   
    updatepayInfo();
    $_SESSION['prompt'] = "Registered Course Deleted";
}



  if(isset($_SESSION['studentno'], $_SESSION['password'])) {

?>

<!DOCTYPE html>
<html>


<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Registration - Student Information System</title>

  <link href="./assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="./assets/css/main.css" rel="stylesheet" type="text/css">
	<!-- <link href="./assets/css/bootstrap4.min.css" rel="stylesheet" type="text/css"> -->
    <link href="././datatable/dataTable.bootstrap.min.css" rel="stylesheet" type="text/css">
<!-- <script src="jquery/jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="datatable/jquery.dataTables.min.js"></script>
<script src="datatable/dataTable.bootstrap.min.js"></script>
 generate datatable on our table 
<script> -->
    <script src="./jquery/jquery.min.js"> </script>
    <script src="./assets/js/bootstrap.min.js"></script>
    <script src="./datatable/jquery.dataTables.min.js"></script>
    <!-- <link rel="stylesheet" type="text/css" href="./../assets/css/bootstrap.min.css"> -->
	<script src="/datatable/dataTable.bootstrap.min.js"></script>
  <!-- <script src="/assets/js/DT_bootstrap.js"></script> -->
	<style>
    	.height10{
			height:10px;
		}
  </style>
<!-- 
<script type="text/javascript">
  (function() {
    window.sib = { equeue: [], client_key: "u9jotzdrjs6jelbtiu0nsn9c" };
    /* OPTIONAL: email to identify request*/
    // window.sib.email_id = 'example@domain.com';
    /* OPTIONAL: to hide the chat on your script uncomment this line (0 = chat hidden; 1 = display chat) */
    // window.sib.display_chat = 0;
    // window.sib.display_logo = 0;
    /* OPTIONAL: to overwrite the default welcome message uncomment this line*/
    // window.sib.custom_welcome_message = 'Hello, how can we help you?';
    /* OPTIONAL: to overwrite the default offline message uncomment this line*/
    // window.sib.custom_offline_message = 'We are currently offline. In order to answer you, please indicate your email in your messages.';
    window.sendinblue = {}; for (var j = ['track', 'identify', 'trackLink', 'page'], i = 0; i < j.length; i++) { (function(k) { window.sendinblue[k] = function(){ var arg = Array.prototype.slice.call(arguments); (window.sib[k] || function() { var t = {}; t[k] = arg; window.sib.equeue.push(t);})(arg[0], arg[1], arg[2]);};})(j[i]);}var n = document.createElement("script"),i = document.getElementsByTagName("script")[0]; n.type = "text/javascript", n.id = "sendinblue-js", n.async = !0, n.src = "https://sibautomation.com/sa.js?key=" + window.sib.client_key, i.parentNode.insertBefore(n, i), window.sendinblue.page();
  })();
</script> -->

</head>
<body>
<!-- call the header -->
  <?php include 'header.php'; ?> 

  <section>

    <div class="container">
      <!-- <strong class="title">My Profile</strong> -->
      <!-- <strong class="title">My Profile</strong> -->
        <!-- <b class="title">Course Registration Page</b> -->
    </div>
    
    
    <!-- <div class="profile-box box-left"> -->
<div class="registration-form box-center clearfix">
<legend class="text-center text-info" > Course registration</legend>

      <?php

        // if(isset($_SESSION['prompt'])) {
        //   showPrompt();
        // }


        $query = "SELECT * FROM students WHERE studentno = '".$_SESSION['studentno']."' AND password = '".$_SESSION['password']."'";

        

        if($result = mysqli_query($con, $query)) {

          $row = mysqli_fetch_assoc($result);
      ?>


          <div class="col-md-7">
                <!-- <table class="table table-responsive"> -->
              <legend class="text-center text-info" >  Student Profile</legend>

            

                    <table id="" class="table table-striped">
                    <tbody>
                        <tr>
                          <div class='info'><td ><b> Student Name</b> </td> </div>
                          <div class='info'><td> <?php echo $row['lastname'].", ".$row['firstname']; ?> </td> </div>
                        </tr>
                        <tr>
                            <td> <div class='info'><span> <b>Student No.</b> </span> </div></td> 
                            <td> <div class='info'><span> <?php echo $row["studentno"]."</div>"; ?> </span></td>
                        
                        </tr>   
                        <tr>
                            <td><div class='info'><span> <b> Index No.</b> </span></div> </td>
                            <td><div class='info'><span>  <?php echo $row["indexNo"]."</div>"; ?></span> </td>
                        </tr> 
                        <tr>
                            <td><div class='info'><span><b> Level</b>  </span></div> </td>
                            <!-- get info -->
                            <?php   $year = "year"; 
                              $query_year = "SELECT * FROM stuyearnsessions WHERE id = '".$row["yrlevel"]."' and type = '" . $year ."'";
                              if($result_year = mysqli_query($con, $query_year)) {
                                $row_year = mysqli_fetch_assoc($result_year);
                                ?>
                            <td><div class='info'><span><?php  $_SESSION['yrl']=$row["yrlevel"]; echo $row_year["typename"];} ?> </div></span> </td>
                        </tr>
                        <tr>
                            <td><div class='info'><span><b> Current Year</b></span></div></td>
                            <td><div class='info'><span> <?php $predate = date('Y'); $curdate = $predate - 1;  echo $curdate."/".$predate;  ?>  &nbsp; &emsp;&emsp;&nbsp; </div></span></td>
                        </tr>
                        <tr>
                            <td><div class='info'><span><b> Department</b> </span></div></td>
                            <?php   $departo = "Department"; 
                              $query_departo = "SELECT * FROM stufacultydepart WHERE id = '".$row["department"]."' and type = '" . $departo ."'";
                              if($result_departo = mysqli_query($con, $query_departo)) {
                                $row_departo = mysqli_fetch_assoc($result_departo);
                                ?>
                            <td><div class='info'><span> <?php $_SESSION['departy']=$row["department"]; echo $row_departo["typename"]."</div>"; }?> </span></td>
                        </tr>
                
            
            <?php
                        $query_date = "SELECT DATE_FORMAT(date_joined, '%m/%d/%Y') FROM students WHERE id = '".$_SESSION['userid']."'";
                        $result = mysqli_query($con, $query_date);

                        $row2 = mysqli_fetch_row($result);
                        ?>   
                        <!-- echo "<div class='info'><strong>Date Joined:</strong> <span>".$row[0]."</span></div>"; -->
                        <tr>
                            <td><div class='info'><span><b> Date registered</b>  </span></div></td>
                            <td><div class='info'><span> <?php echo $row2[0]."</div>"; ?></span></td>
                        </tr>   
                        
                        <tr>
                            <td><div class='info'><span><b> Payment Status</b> </span></div></td>
                            <td><div class='info'><span><i class="text-danger"><?php  echo $row['paymentconfirmMsg']; ?></i></span>
                                </div> </td>
                        </tr>
                  </tbody>
                </table>
                <!-- <div class="options">
        <a class="btn btn-primary" href="editprofile.php">Edit Profile</a>
        <a class="btn btn-success" href="changepassword.php">Change Password</a>
        <a class="btn btn-info" href="changepassword.php">Register Courses</a>
      </div> -->

      </div>
      <?php
        } else {

          die("Error with the query in the database");

        }

      ?>
      
      <div class="col-md-5">
                     <!-- <h4 class="text-center text-info">Add Courses</h4> -->
              <legend class="text-center text-info" >  Add Courses</legend>
              <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?> " method="post" enctype="multipart/form-data">
                        <input type="hidden" name="id" value="<?= $id; ?>">
                        
                        <div class="form-group">
                        <input type="text" name="coursename" value="<?= $coursename; ?>" class="form-control" placeholder="Enter Course Name" required>
                        </div>

                        <!-- <div class="form-group"> -->
                                <!-- <label for="course">Course</label> -->

                                <!-- <SELECT NAME="coursename" class="form-control">select
                                    <OPTION VALUE="select">Select Course -->
                                    <?php 
                                    //loop through all table rows
                                    // $level = $_SESSION['departy'];
                                    // $yrl =  $_SESSION['yrl'];
                                    // $faculty_retrieved = mysqli_query($con, "SELECT * FROM `tbcourses` WHERE `department` = '$level' and `yearlevel` = '$yrl'"); 
                                    // while ($row=mysqli_fetch_array($faculty_retrieved)){
                                    // echo "<OPTION VALUE=$row[coursename]>$row[coursename]> ";
                                    // $_SESSION['crname'] = $row['coursename'];
                                    // }
                                    ?>
                                
                                        <!-- </SELECT> -->
                                   
                                <!-- </div> -->
                            
                                
                            <!-- // `stuNo``coursecode``coursename``yrtrialed``currentdate``payment``confirmedPayment` -->
                            <!-- coursename="";
                            $coursecode="";
                            $yeartrailed="";
                            $amount=""; -->
                      
                            <div class="form-group">
                            <input type="text" name="coursecode" value="<?= $coursecode; ?>" class="form-control" placeholder="Enter Course Code" required>
                        </div>

                      

                               
                        <div class="form-group">
                            <input type="text" name="yrtrailed" value="<?= $yeartrailed; ?>" class="form-control" placeholder="Enter Year Trialed" required>
                        </div>

                        
                       
                                <div class="form-group">
                            <input type="text" name="amount" value="<?= $amount; ?>" class="form-control" placeholder="Amount" readonly> <!--disabled="enabled"> -->
                        </div>

                        <!-- <div class="form-group">
                            <input type="hidden" name="oldimage" value="<?//= $photo; ?>">
                            <input type="file" name="image" class="custom-file">
                            <img src="<//?= $photo; ?>" width="120" class="img-thumbnail">
                        </div> -->
                        <div class="form-group">
                            <?php if ($update == true) { ?>
                            <input type="submit" name="update" class="btn btn-success btn-block" value="Update Record">
                            <?php } else { ?>
                            <input type="submit" name="add" class="btn btn-primary btn-block" value="Add Record">
                            <?php } ?>
                        </div>
                       
                     </form>
                     <?php  if(isset($_SESSION['prompt'])) {
                 showPrompt();
                    }  ?>

        </div>

           

            <!-- <div class="row">
				<a href="./course/print_pdf.php" class="btn btn-success pull-left"><span class="glyphicon glyphicon-print"></span> PDF</a>
			</div> -->

            <!-- tabled -->
            <!-- <div class="row">  -->
    &emsp;    &emsp;    &emsp;    &emsp;    &emsp;    &emsp;    &emsp;    &emsp;    &emsp;    &emsp;                     
        <div class="col-md-12">
                <?php
                $query = 'SELECT * FROM tbtrialedcourses WHERE stuNo = '. $_SESSION['studentno'];
                $stmt = $con->prepare($query);
                $stmt->execute();
                $result = $stmt->get_result();
                $count = mysqli_num_rows($result); //use to check if there has been a registered course
                
                ?>
            <h3 class="text-center text-info">List of Registered Trialed Courses</h3>
         <!-- check for a course registered and paid before download button appears  -->
         <?php //echo $count;
          if($count != 0) {?>
            <a href="./print.php" class="btn btn-success btn-sm "  target="_blank"><span class='glyphicon glyphicon-print'></span> Print all registered courses </a>
           <?php } ?>
            <button class="btn btn-primary btn-sm " data-toggle="modal" data-target="#myModal"><span class='glyphicon glyphicon-pay'></span> Make Payment</button>
                
            <!-- <table class="table table-hover" id="data-table"> -->
                <!-- <table id="myTable" class="table table-bordered table-striped"> -->
                <div class="height10">
		          	</div>
            <table class="table table-bordered table-striped table-hover" id="mytable">

            <thead>
                <tr>
                <th>#</th>
                <th>Course Code</th>
                <th>Course Name</th>
                <th>Year Trialed</th>
                <th>Payment</th>
                <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $no=0; $amoutTotal = 0; while ($row = $result->fetch_assoc()) { $amoutTotal += $row['payment'];?>
                <tr>
                <td><?= $no +=1; //$row['id']; ?></td>
                <!-- <td><img src="<//?= //$row['photo']; ?//>" width="25"></td> -->
                <td><?= $row['coursecode']; ?></td>
                <td><?= $row['coursename']; ?></td>
                <td><?= $row['yrtrialed']; ?></td>
                <td><?= number_format($row['payment'],2); ?></td>
                <td>
                <?php 
                    $paid = "Yes"; if(($row['stuNo']== $_SESSION['studentno']) && ($row['confirmedPayment'] == $paid)){
                ?> 
                 <button class="btn btn-success btn-sm ">Paid </button>
                  <?php }else{ ?>
                    <!-- <a href="./courseregistration.php?details=<?//= //$row['id']; ?>" >  <a href="#myModal"  data-toggle="modal" class="badge badge-primary p-2" > Details</a></a> | -->
                    <a href="./courseregistration.php?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you wish to delete this course?');"><span class='glyphicon glyphicon-trash'></span> Del</a> | 
                    
                  
                    <a href="./courseregistration.php?edit= <?= $row['id']; ?>" class="btn btn-success btn-sm " ><span class='glyphicon glyphicon-edit'></span> Edit</a>
					<!-- <a href='#delete_".$row['id']."' class='btn btn-danger btn-sm'><span class='glyphicon glyphicon-trash'></span> Delete</a> -->
          <?php } ?>
                    <!-- onclick="return confirm('Do you want delete this record?');" -->
                </td>
                </tr>
                <?php 
                    }
                    
                 ?>
                <!-- <tr >
                    <td colspan="2">
                    <a href="./print.php" class="btn btn-success btn-sm "  target="_blank"><span class='glyphicon glyphicon-print'></span> Print all registered courses</a>
                   
                    </td>
                    <td >
                    <a href="" class="btn btn-primary btn-sm "><span class='glyphicon glyphicon-payment'></span> Make Payment</a>
                   
                    </td>
                </tr>
                 -->
              

            </tbody>
            </table>
            <legend class="text-center text-info"> Total Payment: GH&#8373; <?php echo number_format($amoutTotal,2);    ?></legend>
            <a class="btn btn-primary" href="./profile.php">Back</a>
        </div>

        <!-- </div> -->
            </div>   
            
   
      
    <!-- </div> -->

  

  </section>
 

  <!-- make payment informations -->
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Payment Format Info.</h4>
      </div>
      <div class="modal-body">
        
      <div class="list-group">
        <p class="list-group-item active">Use MTN momo payment System</p>
        <ol >
            <p class="list-group-item-heading"> </p>
            <li class="list-group-item-heading">Dial *170#</li>
            <li class="list-group-item-heading">Choose option 1 for "Transfer Money"</li>
            <li class="list-group-item-heading">Choose option 1 for "MoMo User"</li>
            <li class="list-group-item-heading">Enter mobile number <b>0549142719</b></li>
            <li class="list-group-item-heading">Confirm mobile number <b>0549142719</b></li>
            <li class="list-group-item-heading">Enter amount (<b><?php echo " GHȻ ".number_format($amoutTotal,2); ?> </b>)</li> <!-- ¢ -->
            <li class="list-group-item-heading">Enter <b><?php echo $_SESSION['studentno']." Resit";?></b>  as Reference</li>
            <li class="list-group-item-heading">Enter <b>MM PIN</b> to confirm payment</li>
               
        </ol>
            <p>   You will receive SMS notification 30 minutes after payment for confirmation.</p>
      </div>

    <!-- <a href="#" class="list-group-item active">
      <h4 class="list-group-item-heading">First List Group Item Heading</h4>
      <p class="list-group-item-text">List Group Item Text</p>
    </a>
    <a href="#" class="list-group-item">
      <h4 class="list-group-item-heading">Second List Group Item Heading</h4>
      <p class="list-group-item-text">List Group Item Text</p>
    </a>
    <a href="#" class="list-group-item">
      <h4 class="list-group-item-heading">Third List Group Item Heading</h4>
      <p class="list-group-item-text">List Group Item Text</p>
    </a> -->
  <!-- </div> -->
<!-- </div> -->

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
  
</div>



  <!-- <script type="text/javascript">
  $(document).ready(function() {
    $('#data-table').DataTable({
      paging: true
    });
  });
  </script>
   


	<script src="assets/js/jquery-3.1.1.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/main.js"></script> -->

    <!-- generate datatable on our table -->
    <script src="./assets/js/jquery.min.js"></script>
    <script src="./assets/js/bootstrap.min.js"></script>
    <script src="././datatable/jquery.dataTables.min.js"></script>
    <script src="././datatable/dataTable.bootstrap.min.js"></script>

<!-- generate datatable on our table -->
<script>
$(document).ready(function(){
	//inialize datatable
    $('#myTable').DataTable();

    //hide alert
    $(document).on('click', '.close', function(){
    	$('.alert').hide();
    })
});
</script>


 <br>
 <?php include("footer.php"); ?>

</body>
</html>

<?php


  } else {
    header("location:index.php");
    exit;
  }

  unset($_SESSION['prompt']);
  mysqli_close($con);

?>