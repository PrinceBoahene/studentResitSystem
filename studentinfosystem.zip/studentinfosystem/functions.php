<?php 

	function clean($data) {
		$data = trim($data);
		$data = stripslashes($data);

		return $data;
	}

	function showPrompt() {
		echo "<div class='alert alert-success'>".$_SESSION['prompt']."</div>";
	}

	function showError() {
		echo "<div class='alert alert-danger'>".$_SESSION['errprompt']."</div>";
	}

	function updatepayInfo(){
		include './connect.php';
		$confirmYESNO = "Yes";
		$confirmNO = "No";
		$stuNo = $_SESSION['studentno'];
        $query5="SELECT * FROM tbtrialedcourses WHERE stuNo = '$stuNo' AND confirmedPayment = '$confirmYESNO'"; //get paid ones
        $query6="SELECT * FROM tbtrialedcourses WHERE stuNo = '$stuNo' AND confirmedPayment = '$confirmNO'";  //get unpaid ones
        // $result5 = mysqli_query($con, $query5);
        // $result6 = mysqli_query($con, $query6);
        $stmt = $con->prepare($query5);
        $stmt->execute();
        $result5 = $stmt->get_result();

        $stmt = $con->prepare($query6);
        $stmt->execute();
        $result6 = $stmt->get_result();

        $paid_Counter = 0;
        $Num_of_all_registered_courses = 0;
        $amountpaidy = 0;
        // for($i=0;$i<=$result5-.mysqli_fetch_assoc();$i++){
        //     $i  
        // }
        while ($row5 = $result5->fetch_assoc()) {
                $paid_Counter += 1;
        }
        while ($row6 = $result6->fetch_assoc()) {
            $Num_of_all_registered_courses += 1;
            $amountpaidy = $row6['payment'];
    }

	if($paid_Counter == ($paid_Counter + $Num_of_all_registered_courses))
    $payMsg = "No payment";
    else
      $payMsg = "Payment of ".$paid_Counter." out of ". ($paid_Counter + $Num_of_all_registered_courses)." registered courses";


		$query="UPDATE students SET paymentconfirmMsg=? WHERE studentno=$stuNo";
		$stmt=$con->prepare($query);
		$stmt->bind_param("s",$payMsg);
		$stmt->execute();
	


	}
?>