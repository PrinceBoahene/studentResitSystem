<?php 

  session_start();

  require 'connect.php';
  require './functions.php';


  if(isset($_POST['reset'])) {
    // `id`, `password`, `studentno`, `firstname`, `lastname`, `course`, `yrlevel`, `date_joined`, `email`, `indexNo`,
    //  `contact`, `Faculty`, `session`
   
    $studno = $_POST['studentno'];
    $contact = $_POST['contact'];
    $newpassGenerate = "Gen".substr($studno,0,3).substr($contact,1,3);
    // $pword = md5($_POST['password']); 
    $pword = md5($newpassGenerate);

    $query = "SELECT studentno FROM students WHERE studentno = '$studno'";

    $result = mysqli_query($con,$query);

    if(mysqli_num_rows($result) == 1) {

      $query = "SELECT studentno FROM students WHERE studentno = '$studno' AND contact= '$contact'";
      $result = mysqli_query($con,$query);

      if(mysqli_num_rows($result) == 1) {

        $query = "UPDATE students SET password = '$pword' WHERE studentno ='$studno' AND contact= '$contact'";

        if(mysqli_query($con, $query)) {

          // send auto generate password to the user through SMS
         ?>
         <a href="./forgottenpasswordmail.php?contact= <?= $contact; ?>"></a>
         <?php


          $_SESSION['prompt'] = "New Password registered. You can now log in with '". $newpassGenerate ."'";
          
          header("location: index.php");
          exit;

        } else {

          $_SESSION['errprompt'] = "Error with the change password";

        }

      } else {

        $_SESSION['errprompt'] = "Incorrect credentials check your contact and student number well.";

      }

    } else {

      $_SESSION['errprompt'] = "Credentials are incorrect.";

    }

  } 


  // $result = mysqli_query($con, "SELECT * FROM stufacultydepart");

?>

<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Register - Student Information System</title>

	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/main.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>
<body>

  <?php include 'header.php'; ?>

  <section class="center-text">
    
    <strong>Create New Password now.</strong>

    <div class="login-form box-center">

    <?php 
        if(isset($_SESSION['errprompt'])) {
          showError();
        }
    ?>

      <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
      <!-- <form action="./register.php" method="POST"> -->
        
        <div class="row">
          <div class="account-info col-sm-14">
          
            <fieldset>
              <legend>&emsp;  Student Personal Information </legend>
             
              <div class="form-group">
                <label for="studentno">Student Number</label>
                <input type="text" class="form-control" name="studentno" placeholder="Student Number (must be unique)" required>
              </div>


              <div class="form-group">
                <label for="contact">Contact</label>
                <input type="text" class="form-control" name="contact" placeholder="Contact" required>
              </div>

    
              <!-- <div class="form-group">
                <label for="password">New Password</label>
                <input type="password" class="form-control" name="password" placeholder="Password" required>
              </div> -->
           
       


              <a href="index.php"  class="btn btn-primary">Go back</a>
        <input class="btn btn-primary" type="submit" name="reset" value="Reset">


            </fieldset>
               
          </div>

          </div>
        
        
        
        

      </form>
    </div>

  </section>


	<script src="assets/js/jquery-3.1.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>

<?php 

  unset($_SESSION['errprompt']);
  mysqli_close($con);

?>