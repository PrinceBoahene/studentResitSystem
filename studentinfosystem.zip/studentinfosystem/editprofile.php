<?php 

  session_start();

  require 'connect.php';
  require './functions.php';

  if(isset($_POST['update'])) {

    $fname = $_POST['firstname'];
    $lname = $_POST['lastname'];
    $email = $_POST['email'];
    $sesion = $_POST['sesion'];
    $course = $_POST['course']; //department
    $yrlevel = $_POST['yrlevel'];
    $indxnum = $_POST['IndexNum'];
    $contact= $_POST['contact'];
    $faculty = $_POST['faculty'];
    // check if selection boxes were seleted
    if(($course == "Select Department") && ($sesion !== "Select Session") && ($faculty !== "Select Faculty") && ($yrlevel !== "Select Year Level")){
      $query = "UPDATE students SET firstname = '$fname', lastname = '$lname',indexNo ='$indxnum', yrlevel = '$yrlevel',
      email = '$email', session = '$sesion',contact ='$contact',Faculty='$faculty' WHERE id='".$_SESSION['userid']."'";
  
    }
    elseif (($course !== "Select Department") && ($sesion == "Select Session") && ($faculty !== "Select Faculty") && ($yrlevel !== "Select Year Level")){
      $query = "UPDATE students SET firstname = '$fname', lastname = '$lname',indexNo ='$indxnum', department = '$course', yrlevel = '$yrlevel',
      email = '$email', contact ='$contact',Faculty='$faculty' WHERE id='".$_SESSION['userid']."'";
  
    }elseif(($course !== "Select Department") && ($sesion !== "Select Session") && ($faculty == "Select Faculty") && ($yrlevel !== "Select Year Level")){
      $query = "UPDATE students SET firstname = '$fname', lastname = '$lname',indexNo ='$indxnum', department = '$course', yrlevel = '$yrlevel',
      email = '$email', session = '$sesion',contact ='$contact' WHERE id='".$_SESSION['userid']."'";
  
    }
    elseif(($course !== "Select Department") && ($sesion !== "Select Session") && ($faculty !== "Select Faculty") && ($yrlevel == "Select Year Level")){
      $query = "UPDATE students SET firstname = '$fname', lastname = '$lname',indexNo ='$indxnum', department = '$course', yrlevel = '$yrlevel',
      email = '$email', session = '$sesion',contact ='$contact' WHERE id='".$_SESSION['userid']."'";
  
    }
    elseif(($course == "Select Department") && ($sesion == "Select Session") && ($faculty == "Select Faculty") && ($yrlevel == "Select Year Level")){
      $query = "UPDATE students SET firstname = '$fname', lastname = '$lname',indexNo ='$indxnum',
      email = '$email',contact ='$contact' WHERE id='".$_SESSION['userid']."'";
  
    }else{
      $query = "UPDATE students SET firstname = '$fname', lastname = '$lname',indexNo ='$indxnum', department = '$course', yrlevel = '$yrlevel',
      email = '$email', session = '$sesion',contact ='$contact',Faculty='$faculty' WHERE id='".$_SESSION['userid']."'";
  
    }
    // `id`, `password`, `studentno`, `firstname`, `lastname`, `course`, `yrlevel`, `date_joined`, `email`, `indexNo`, `contact`, `Faculty`, `session`
    
    if($result = mysqli_query($con, $query)) {

      $_SESSION['prompt'] = "Profile Updated";
      header("location:profile.php");
      exit;

    } else {

      die("Error with the query");

    }

  }

  if(isset($_SESSION['studentno'], $_SESSION['password'])) {

    $qry = mysqli_query($con,"SELECT * FROM students where id = {$_SESSION['userid']} ");
    $data = mysqli_fetch_array($qry);
    extract($data);

?>

<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Edit Profile - Student Information System</title>

	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/main.css" rel="stylesheet">


    
</head>
<body>

  <?php include 'header.php'; ?>

  <section>
    
    <div class="container">
      <!-- <strong class="title">Edit Profile</strong> -->
    </div>
    

    <!-- <div class="edit-form box-left clearfix"> -->
    <div class="registration-form box-center">
    <legend class="text-center text-info" > Edit Student Profile</legend>

      <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">

        <div class="form-group">
          <!-- <label>Student No:   </label> -->
          
          <?php 
            $query = "SELECT * FROM students WHERE id = '".$_SESSION['userid']."'";
            $result = mysqli_query($con, $query);
            $row = mysqli_fetch_row($result);

            // echo "<b>".$row[2]."</b>";
            $stuN = $row[2];
            $indxnum = $row[9]; // get index number
          ?>

        
        </div>
        <div class="form-group">
          <label for="firstname">Student Number</label>
          <input type="text" class="form-control" value="<?php echo $stuN ?>" disabled="disabled">
        </div>

        <div class="form-group">
          <label for="firstname">First Name</label>
          <input type="text" class="form-control" name="firstname" value="<?php echo $firstname ?>" placeholder="First Name" required>
        </div>


        <div class="form-group">
          <label for="lastname">Last Name</label>
          <input type="text" class="form-control" name="lastname" value="<?php echo $lastname ?>" placeholder="Last Name" required>
        </div>

        <div class="form-group">
          <label for="contact">Contact</label>
          <input type="text" class="form-control" name="contact" value="<?php echo $contact ?>" placeholder="Contact" required>
        </div>

        <div class="form-group">
          <label for="indexNumber">Index Number</label>
          <input type="text" class="form-control" name="IndexNum" value="<?php echo $indxnum ?>" placeholder="Index Number" required>
        </div>

        <div class="form-group">
          <label for="email">Email</label>
          <input type="email" class="form-control" name="email" value="<?php echo $email ?>" placeholder="Email" required>
        </div>


        <div class="form-group">
                <label for="course">Department</label>

                <SELECT NAME="course" class="form-control">select
                  <OPTION >Select Department
                  <?php
                  //loop through all table rows
                  $level = "department";
                  $year_retrieved = mysqli_query($con, "SELECT * FROM `stufacultydepart` WHERE `type` = '$level'"); 
                  while ($row=mysqli_fetch_array($year_retrieved)){
                  echo "<OPTION VALUE = $row[id] > $row[typename] </option>";
                  // <?php echo $row['Gender'] == "Female" ? "selected" : ''; 
                    }
                    ?>
                  </OPTION>
				    	</SELECT>

        </div>
        <div class="form-group">
                <label for="course">Faculty</label>

                <SELECT NAME="faculty" class="form-control">select
                  <OPTION >Select Faculty
                  <?php
                  //loop through all table rows
                  $fat = "Faculty";
                  $fat_retrieved = mysqli_query($con, "SELECT * FROM `stufacultydepart` WHERE `type` = '$fat'"); 
                  while ($row=mysqli_fetch_array($fat_retrieved)){
                  echo "<OPTION VALUE = $row[id] > $row[typename] </option>";
                  // <?php echo $row['Gender'] == "Female" ? "selected" : ''; 
                    }
                    ?>
                  </OPTION>
				    	</SELECT>

        </div>
    

        <div class="form-group">
                <label for="yrlevel">Year Level</label>

                <SELECT NAME="yrlevel" class="form-control">select
                  <OPTION VALUE="select">Select Year Level
                  <?php
                  //loop through all table rows
                  $level = "year";
                  $year_retrieved = mysqli_query($con, "SELECT * FROM `stuyearnsessions` WHERE `type` = '$level'"); 
                  while ($row=mysqli_fetch_array($year_retrieved)){
                  echo "<OPTION VALUE = $row[id] > $row[typename]";
					
                    }
                    ?>
				    	</SELECT>

        </div>
              
        <div class="form-group">
                <label for="sesion">Choose Session</label>

                <SELECT NAME="sesion" class="form-control">select
                  <OPTION VALUE="select">Select Session
                  <?php
                  //loop through all table rows
                  $level = "session";
                  $year_retrieved = mysqli_query($con, "SELECT * FROM `stuyearnsessions` WHERE `type` = '$level'"); 
                  while ($row=mysqli_fetch_array($year_retrieved)){
                  echo "<OPTION VALUE=$row[id]>$row[typename]";
					
                    }
                    ?>
				    	</SELECT>

        </div>
       
        <div class="form-footer">
          <a href="profile.php" class="btn btn-primary">Go back</a>
          <input class="btn btn-primary" type="submit" name="update" value="Update Profile">
        </div>
        

      </form>
      <br>

    </div>

  </section>


	<script src="assets/js/jquery-3.1.1.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/main.js"></script>
</body>
</html>

<?php 

  } else {
    header("location:profile.php");
  }

  mysqli_close($con);

?>