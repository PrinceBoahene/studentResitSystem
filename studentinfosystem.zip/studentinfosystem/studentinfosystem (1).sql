-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2021 at 01:58 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentinfosystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `administor`
--

CREATE TABLE `administor` (
  `id` int(50) NOT NULL,
  `name` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `adminID` varchar(200) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `administor`
--

INSERT INTO `administor` (`id`, `name`, `password`, `adminID`, `status`) VALUES
(1, 'admin2', 'admin2', 'ADM_manager', 0),
(2, 'admin3', 'admin3', 'worker', 1);

-- --------------------------------------------------------

--
-- Table structure for table `courselecturer`
--

CREATE TABLE `courselecturer` (
  `id` int(50) NOT NULL,
  `name` varchar(250) NOT NULL,
  `Contact` varchar(200) NOT NULL,
  `staffId` varchar(200) NOT NULL,
  `course` varchar(250) NOT NULL,
  `department` varchar(250) NOT NULL,
  `status` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courselecturer`
--

INSERT INTO `courselecturer` (`id`, `name`, `Contact`, `staffId`, `course`, `department`, `status`) VALUES
(1, 'Dr. Emelia', '0548392819', 'CSHST 20', 'Database', 'Department of Computer Science', 1),
(2, 'Dr. Ansong', '0547274826', 'CSHST 21', 'Ai', 'Department of Computer Science', 1),
(3, 'S.K. Opoku', '05487372773', 'CSHST 19', 'Java', 'Department of Computer Science', 1);

-- --------------------------------------------------------

--
-- Table structure for table `noticetbl`
--

CREATE TABLE `noticetbl` (
  `noteid` int(11) NOT NULL,
  `notice` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `postdate` varchar(250) NOT NULL,
  `lastupdate` varchar(250) NOT NULL,
  `destination` varchar(250) NOT NULL,
  `status` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `noticetbl`
--

INSERT INTO `noticetbl` (`noteid`, `notice`, `description`, `postdate`, `lastupdate`, `destination`, `status`) VALUES
(1, 'KsTU Online Resit Registration', 'Online Resit Registration will end by 5:00 pm on 2nd August 2021. \r\nPlease kindly register before the due date. \r\n', '23/07/2021', '0000-00-00', 'All Students ', 1),
(5, 'Resit Registration', 'The institution resit registration ends 21st June, 2021. Kindly make payment for all your registered courses.\r\nThank you.', '23/07/2021', '0000-00-00', 'All Students ', 1),
(8, 'Mid Semester Examination', 'Dear Student, mid sem examination will start from next week on 24th June, 2021.\r\nKindly prepare well for this examination.\r\nThank you \r\nGood Luck.', '23/07/2021', '24/06/2021 05:47:30', 'All Students ', 1),
(9, 'SRC souvenir ', 'All class representatives are to come for their class souvenirs at the SRC hall\r\nThank you\r\n', '23/07/2021', '25/06/2021 07:59:14', 'All Students ', 0),
(10, 'Course Registration', '📍Notice: Late Registration With 100ghc penalty. Failure to register before 14th July, you cease to be a student.\r\n\r\n[See Here]\r\nhttps://twitter.com/ask_kstu/status\r\n/1410990240559370248?s=20\r\n.\r\n.\r\n.\r\n#AskKsTUReporting\r\n#ConnectingCampus\r\n\r\nKINDLY FO', '18/07/2021', '02/07/2021 03:59:08', 'All Students ', 0),
(11, 'General Meeting', 'Your President want to meet you all.', '18/07/2021', '18/07/2021 03:52:47', 'Compssa', 1),
(14, 'COMPSSA EXECUTIVES', 'The easiest way to understand computer networking is through the human communication\r\nmodel. Suppose you are applying for a job in France after graduation. You need information about\r\ndifferent employers. The first requirement for a network—informati', '22/07/2021', '22/07/2021 05:19:43', 'COMPSSA', 1);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(100) NOT NULL,
  `password` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `studentno` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `firstname` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `department` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `yrlevel` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `date_joined` date NOT NULL,
  `email` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `indexNo` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `contact` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Faculty` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `session` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(50) NOT NULL,
  `paymentconfirmMsg` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `password`, `studentno`, `firstname`, `lastname`, `department`, `yrlevel`, `date_joined`, `email`, `indexNo`, `contact`, `Faculty`, `session`, `status`, `paymentconfirmMsg`) VALUES
(10, '51deebe1e9018c9dfb5577820fab33b1', '05180027466', 'Prince', 'Boahene', '2', '1', '2021-07-20', 'boaheneprince24@gmail.com', '051800461', '0549142719', '1', '6', 1, 'Payment of 3 out of 4 registered courses'),
(12, '12345', '05180213318', 'Cudjoe', 'Joseph', '2', '1', '2021-06-22', 'cudjoejoseph655@gmail.com', '051800468', '0240667983', '1', '6', 1, 'Full payment'),
(15, 'nelson', '05180213310', 'Nelson ', 'Kofi', '2', '1', '2021-07-16', 'nelson@gmail.com', '051800122', '0557321718', '1', '6', 1, 'Full payment'),
(16, 'alphy', '05180364056', 'Alpha', 'Ampem', '2', '1', '2021-07-19', 'nahnahkodjo@gmail.com', '051800490', '0596049518', '1', '6', 1, 'No Payment'),
(17, 'airbender', '05180287135', 'Edmund', 'Sai', '2', '1', '2021-07-19', 'edmundsai97@gmail.com', '051800483', '0249474860', '1', '6', 1, 'Payment of 0 out of 1 registered courses'),
(18, '0549', '05180027467', 'James', 'Oteng', '2', '1', '2021-07-22', 'otengjames@gmail.com', '051800462', '0549142719', '1', '6', 1, 'No Payment'),
(19, 'henry', '05192129', 'Henry', 'Owusu', '2', '1', '2021-07-22', 'owusuhenery@gmail.com', '10020120', '054932283823', '1', '6', 1, 'No Payment'),
(20, '    ', '004394', 'Kwaka', 'kak', '2', '1', '2021-07-22', 'akak@gmail', '03239', '023902', '1', '6', 1, 'No Payment'),
(21, '38f629170ac3ab74b9d6d2cc411c2f3c', '053884332', 'Akua', 'Bemah', '2', '1', '2021-07-23', 'Bemah@gmail.com', '049349434', '902302323', '1', '6', 1, 'No Payment');

-- --------------------------------------------------------

--
-- Table structure for table `stufacultydepart`
--

CREATE TABLE `stufacultydepart` (
  `id` int(200) NOT NULL,
  `typename` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `typecode` varchar(200) NOT NULL,
  `status` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stufacultydepart`
--

INSERT INTO `stufacultydepart` (`id`, `typename`, `type`, `typecode`, `status`) VALUES
(1, 'Faculty of Applied Sciences and Technology', 'Faculty', 'FAST', 1),
(2, 'Department of Computer Science', 'Department', 'COMPSSA', 1),
(3, 'Department of Hospital and Catering', 'Department', 'HCI', 0),
(4, 'Department of Engineering', 'Department', 'ENG20', 0),
(7, 'Department of Clinical and Nursing', 'Department', 'CL22', 1),
(8, 'Department of Health Sciences', 'Department', 'DHS', 1),
(9, 'Faculty of Business', 'Faculty', 'FOB', 1),
(10, 'Faculty of Business', 'Faculty', 'FOB', 1),
(11, 'Faculty of Business2', 'Faculty', 'FOB2', 1),
(12, 'Faculty of Health', 'Faculty', 'FH', 1),
(13, 'Department of Agriculture', 'Department', 'AGRI', 1),
(14, 'Faculty of Agriculty', 'Faculty', 'FAGRI', 1),
(15, 'Department of Accounting', 'Department', 'Accas', 1),
(16, 'Mechanical Department', 'Department', 'MECH', 1);

-- --------------------------------------------------------

--
-- Table structure for table `stuyearnsessions`
--

CREATE TABLE `stuyearnsessions` (
  `id` int(50) NOT NULL,
  `typename` varchar(250) NOT NULL,
  `type` varchar(250) NOT NULL,
  `status` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stuyearnsessions`
--

INSERT INTO `stuyearnsessions` (`id`, `typename`, `type`, `status`) VALUES
(1, 'First Year', 'year', 1),
(2, 'Second Year', 'year', 1),
(3, 'Third Year', 'year', 1),
(5, 'Regular', 'session', 1),
(6, 'Evening', 'session', 1),
(7, 'Weekends', 'session', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbcourses`
--

CREATE TABLE `tbcourses` (
  `id` int(50) NOT NULL,
  `coursename` varchar(200) NOT NULL,
  `coursecode` varchar(200) NOT NULL,
  `Department` varchar(200) NOT NULL,
  `yearLevel` varchar(200) NOT NULL,
  `resitAmount` varchar(200) NOT NULL,
  `lecturer` varchar(200) NOT NULL,
  `status` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbcourses`
--

INSERT INTO `tbcourses` (`id`, `coursename`, `coursecode`, `Department`, `yearLevel`, `resitAmount`, `lecturer`, `status`) VALUES
(1, 'Circuit Theory', 'CSH 203', 'Department of Computer Science', 'First Year', '70', 'Mammudu', 1),
(2, 'African Studies', 'AFS 201', 'Department of Computer Science', 'First Year', '30', 'Prince', 1),
(3, 'IT Mathematics', 'CSH 201', 'Department of Computer Science', 'First Year', '50', 'Dr. Ansong', 1),
(4, 'InfoTech', 'CSH 207', 'Department of Computer Science', 'Second Year', '50', 'Dr. Ansong', 1),
(5, 'Agriculture Business', 'AGRBUSI', 'Department of Computer Science', 'First Year', '50', 'Dr. Emelia', 1),
(6, 'Database ', 'CSH 201', 'Department of Computer Science', 'First Year', '100', 'Dr. Emelia', 1),
(7, 'Business management', 'BM 565', 'Department of Agriculture', 'Second Year', '100', 'Dr. Ansong', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbtrialedcourses`
--

CREATE TABLE `tbtrialedcourses` (
  `id` int(11) NOT NULL,
  `stuNo` varchar(200) NOT NULL,
  `coursecode` varchar(200) NOT NULL,
  `coursename` varchar(200) NOT NULL,
  `yrtrialed` varchar(200) NOT NULL,
  `currentdate` date DEFAULT current_timestamp(),
  `payment` varchar(200) NOT NULL,
  `confirmedPayment` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbtrialedcourses`
--

INSERT INTO `tbtrialedcourses` (`id`, `stuNo`, `coursecode`, `coursename`, `yrtrialed`, `currentdate`, `payment`, `confirmedPayment`) VALUES
(3, '0518002', 'CSh 323', 'Info Tech', '2020', '2021-06-07', '90', 'No'),
(7, '05180023', 'Cash 233', 'Discrete Mathematics', '2020', '2021-06-02', '50', 'No'),
(10, '0518002', 'CSh 323', 'IT Mathematice', '2021', '2021-06-04', '100', 'Yes'),
(11, '0518002', 'COS 301', 'Comm Skills', '2020', '2021-06-04', '200', 'No'),
(12, '0518002', 'COS 301', 'Discrete Mathematics', '2021', '2021-06-07', '100', 'Yes'),
(14, '0518002', 'DS 201', 'Data Structures', '2020', '2021-06-04', '100', 'Yes'),
(15, '05181223', 'CSh 323', 'IT Mathematice', '2020', '2021-06-04', '80', 'Yes'),
(17, '0557321718', 'CSh 323', 'Comm Skills', '2020', '2021-06-04', '60', 'Yes'),
(20, '05180230293', 'Cash 233', 'IT Mathematice', '2019', '2021-06-07', '100', 'Yes'),
(21, '05180230293', 'CSH 291', 'Data Structures', '2012', '2021-06-07', '120', 'Yes'),
(22, '05180230293', 'DS 201', 'IT Mathematice', '2012', '2021-06-07', '50', 'Yes'),
(23, '05180230293', 'CSH 291', 'Discrete Mathematics', '2012', '2021-06-07', '90', 'Yes'),
(24, '0518001', 'DS 201', 'Data Structures', '2012', '2021-06-07', '100', 'Yes'),
(25, '0518001', 'DS 201', 'Discrete Mathematics', '2012', '2021-06-07', '80', 'Yes'),
(26, '0518001', 'DS 201', 'Comm Skills', '2012', '2021-06-07', '100', 'Yes'),
(27, '0518001', 'CSH 383', 'Info Tech', '2020', '2021-06-07', '100', 'Yes'),
(29, '0518001', 'COS 301', 'IT Mathematice', '2012', '2021-06-07', '100', 'Yes'),
(30, '0518002', 'Cash 233', 'Data Structures', '2020', '2021-06-08', '120', 'Yes'),
(31, '51800', 'CSH 383', 'Comm Skills', '2020', '2021-06-09', '80', 'Yes'),
(32, '51800', 'CSH 291', 'Info Tech', '2020', '2021-06-09', '80', 'Yes'),
(33, '51800', 'COS 301', 'Discrete Mathematics', '2020', '2021-06-09', '80', 'Yes'),
(42, '0518002', 'CSH 291', 'Info Tech', '2021', '2021-06-10', '60', 'No'),
(45, '05170243270', 'Gh12', 'Financial management', '2018', '2021-06-12', '55', 'Yes'),
(54, '2147483647', 'COS 301', 'Info Tech', '2020', '2021-06-13', '55', 'Yes'),
(55, '2147483647', 'CSH 383', 'Discrete Mathematics', '2019', '2021-06-13', '55', 'Yes'),
(58, '2147483647', 'COS 301', 'Info Tech', '2020', '2021-06-13', '55', 'Yes'),
(59, '2147483647', 'CSH 383', 'IT Mathematice', '2020', '2021-06-13', '55', 'Yes'),
(60, '2147483647', 'COS 301', 'Info Tech', '2021', '2021-06-13', '55', 'No'),
(61, '2147483647', 'COS 301', 'Info Tech', '2021', '2021-06-13', '55', 'Yes'),
(63, '2147483647', 'COS 301', 'Discrete Mathematics', '2020', '2021-06-13', '55', 'Yes'),
(64, '2147483647', 'COS 301', 'Software Engineering', '2020', '2021-06-13', '55', 'No'),
(65, '0557321718', 'CSH 383', 'Discrete Mathematics', '2020', '2021-06-13', '55', 'Yes'),
(66, '0557321718', 'CSH 383', 'IT Mathematice', '2020', '2021-06-14', '55', 'No'),
(67, '0557321718', 'COS 301', 'Discrete Mathematics', '2019', '2021-06-14', '55', 'No'),
(68, '0557321718', 'COS 301', 'Info Tech', '2019', '2021-06-14', '55', 'No'),
(69, '0557321718', 'CSH 383', 'Discrete Mathematics', '2020', '2021-06-14', '55', 'No'),
(73, '0518008', 'DS 201', 'Info Tech', '2022', '2021-06-22', '80', 'Yes'),
(74, '0518008', 'CSh 323', 'IT Mathematice', '2018', '2021-06-15', '55', 'No'),
(75, '0518008', 'COS 301', 'Comm Skills', '2021', '2021-06-16', '55', 'No'),
(76, '05180213318', 'COS 301', 'Discrete Mathematics', '2021', '2021-06-22', '55', 'Yes'),
(77, '05180213318', 'CSH 383', 'Comm Skills', '2019', '2021-06-22', '55', 'Yes'),
(78, '05180213318', 'Cash 233', 'Comm Skills', '2018', '2021-06-22', '55', 'Yes'),
(80, '05180319921', 'Csh111', 'Info tech', '3', '2021-06-25', '55', 'Yes'),
(81, '05180319921', 'Csh322', 'Vb', '3', '2021-06-25', '55', 'Yes'),
(90, '051111', 'COS 301', 'Discrete Mathematics', '2018', '2021-06-29', '55', 'No'),
(91, '051111', 'COS 301', 'Discrete Mathematics', '2021', '2021-06-29', '55', 'No'),
(92, '05180027466', 'CSH 291', 'Info Tech', '2021', '2021-07-02', '55', 'Yes'),
(93, '05180027466', 'DS 201', 'IT Mathematice', '2021', '2021-07-02', '55', 'Yes'),
(94, '05180027466', 'COS 301', 'Artificial Intelligence', '2019', '2021-07-13', '55', 'Yes'),
(98, '05180213310', 'CSH 383', 'Comm Skills', '2020', '2021-07-16', '55', 'Yes'),
(99, '05180287135', 'CSH 289', 'Communication skills', '2017', '2021-07-19', '55', 'No'),
(100, '05180027466', 'CSh 323', 'principle of management', '2019', '2021-07-23', '55', 'No');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administor`
--
ALTER TABLE `administor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courselecturer`
--
ALTER TABLE `courselecturer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `noticetbl`
--
ALTER TABLE `noticetbl`
  ADD PRIMARY KEY (`noteid`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stufacultydepart`
--
ALTER TABLE `stufacultydepart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stuyearnsessions`
--
ALTER TABLE `stuyearnsessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbcourses`
--
ALTER TABLE `tbcourses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbtrialedcourses`
--
ALTER TABLE `tbtrialedcourses`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administor`
--
ALTER TABLE `administor`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `courselecturer`
--
ALTER TABLE `courselecturer`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `noticetbl`
--
ALTER TABLE `noticetbl`
  MODIFY `noteid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `stufacultydepart`
--
ALTER TABLE `stufacultydepart`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `stuyearnsessions`
--
ALTER TABLE `stuyearnsessions`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbcourses`
--
ALTER TABLE `tbcourses`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbtrialedcourses`
--
ALTER TABLE `tbtrialedcourses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
