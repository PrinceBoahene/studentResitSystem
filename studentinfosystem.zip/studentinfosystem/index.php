<?php 

  session_start();

  require 'connect.php';
  require 'functions.php';

  // if ( $detect->isMobile() || $detect->isAndroidOS() || $detect->version('iPhone') 
  // || $detect->version('iPad') || $detect->isiOS() ) 
  // { header('Location: ./index.php', true, 301);  
  //    exit; }
// reset pass on the same page
  // $_SESSION['forgetpass'] = False;

  if(isset($_POST['login'])) {

    $uname = $_POST['studentno'];
    $pword = md5(clean($_POST['password']));

    $query = "SELECT * FROM students WHERE studentno = '$uname' AND password = '$pword'";
    $adminquery = "SELECT * FROM administor WHERE name = '$uname' AND password = '$pword'";

    $result = mysqli_query($con, $query);
    $adminresult = mysqli_query($con, $adminquery);


    if(mysqli_num_rows($result) > 0) {

      $row = mysqli_fetch_assoc($result);

      $_SESSION['userid'] = $row['id'];
      $_SESSION['studentno'] = $row['studentno'];
      $_SESSION['password'] = $row['password'];
      $_SESSION['lastname'] = $row['lastname'];
      $_SESSION['firstname'] = $row['firstname'];
      $_SESSION['depart'] = $row['course'];
      // $_SESSION['forgetpass'] = False;
      header("location:profile.php");
      exit;

    }elseif(mysqli_num_rows($adminresult) > 0){

      header("location: ./admin/");

    }
    
    else {

      $_SESSION['errprompt'] = "Wrong username or password.";

    }

  }

  if(!isset($_SESSION['studentno'], $_SESSION['password'])) {

?>

<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Login - Student OR Square</title>

	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/main.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>
<body>

  <?php include 'header.php'; ?>

  <section class="center-text">
    
    <strong>Student Login Portal</strong>

    <div class="login-form box-center">
      <?php 

        if(isset($_SESSION['prompt'])) {
          showPrompt();
        }

        if(isset($_SESSION['errprompt'])) {
          showError();
        }

      ?>
      <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
        
        <div class="form-group">
          <label for="studentno" class="sr-only">Student Number</label>
          <input type="number" class="form-control" name="studentno" placeholder="Student Number" required autofocus>
        </div>

        <div class="form-group">
          <label for="password" class="sr-only">Password</label>
          <input type="password" class="form-control" name="password" placeholder="Password" required>
        </div>
        <a href="register.php">Register new account?</a>
        <input class="btn btn-primary" type="submit" name="login" value="Log In"><br><br>
        
        <br>
        <a href="./forgottenpassword.php"><i>Forgotten password?</i></a>
        
      </form>
    </div>

  </section>


	<script src="assets/js/jquery-3.1.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>

<?php

  } else {
    header("location: profile.php");
    exit;
  }

  unset($_SESSION['prompt']);
  unset($_SESSION['errprompt']);

  mysqli_close($con);

?>