<?php 

  session_start();

  require 'connect.php';
  require './functions.php';

  if(isset($_SESSION['studentno'], $_SESSION['password'])) {

?>

<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Profile - Student Information System</title>

  <link href="assets/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/css/main.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  
<!-- <script type="text/javascript">
  (function() {
    window.sib = { equeue: [], client_key: "u9jotzdrjs6jelbtiu0nsn9c" };
    /* OPTIONAL: email to identify request*/
    // window.sib.email_id = 'example@domain.com';
    /* OPTIONAL: to hide the chat on your script uncomment this line (0 = chat hidden; 1 = display chat) */
    // window.sib.display_chat = 0;
    // window.sib.display_logo = 0;
    /* OPTIONAL: to overwrite the default welcome message uncomment this line*/
    // window.sib.custom_welcome_message = 'Hello, how can we help you?';
    /* OPTIONAL: to overwrite the default offline message uncomment this line*/
    // window.sib.custom_offline_message = 'We are currently offline. In order to answer you, please indicate your email in your messages.';
    window.sendinblue = {}; for (var j = ['track', 'identify', 'trackLink', 'page'], i = 0; i < j.length; i++) { (function(k) { window.sendinblue[k] = function(){ var arg = Array.prototype.slice.call(arguments); (window.sib[k] || function() { var t = {}; t[k] = arg; window.sib.equeue.push(t);})(arg[0], arg[1], arg[2]);};})(j[i]);}var n = document.createElement("script"),i = document.getElementsByTagName("script")[0]; n.type = "text/javascript", n.id = "sendinblue-js", n.async = !0, n.src = "https://sibautomation.com/sa.js?key=" + window.sib.client_key, i.parentNode.insertBefore(n, i), window.sendinblue.page();
  })();
</script> -->
</head>
<body>
<!-- call the header -->
  <?php include 'header.php'; ?> 

  <section>

    <div class="container">
    <?php 
//$sql="select noteid,notice,description,postdate,destination from noticetbl ";
    //$result = mysqli_query($con,$sql);
     // while($rows=mysqli_fetch_assoc($result)){
	//extract($rows);
	?>
  <?php //echo "<marquee>  <b>".$rows['notice'] ."</b>  ". $rows['description']." <b>---</b> ". $rows['postdate']." <b>---</b> ". $rows['destination']."</marquee>";?>

    <?php //}
    ?>
	
    </div>
    
    
    <!-- <div class="profile-box box-left"> -->
<div class="registration-form box-center clearfix">

<legend class="text-center text-info" > Student Profile</legend>
<br>
      <?php

        if(isset($_SESSION['prompt'])) {
          showPrompt();
        }


        $query = "SELECT * FROM students WHERE studentno = '".$_SESSION['studentno']."' AND password = '".$_SESSION['password']."'";

        

        if($result = mysqli_query($con, $query)) {

          $row = mysqli_fetch_assoc($result);

          // echo "<div class='info'><strong>Student No:</strong> <span>".$row['studentno']."</span></div>";
          // echo "<div class='info'><strong>Student Name:</strong> <span>".$row['lastname'].", ".$row['firstname']."</span></div>";
          // echo "<div class='info'><strong>Course:</strong> <span>".$row['course']."</span></div>";
          // echo "<div class='info'><strong>Year Level:</strong> <span>".$row['yrlevel']."</span></div>";
      ?>
<!-- `password`, `studentno`, `firstname`, `lastname`, `course`, `yrlevel`, `date_joined`, `email`, `indexNo`, `contact`, `Faculty`, `session` -->
          <div class="col-md-10">
                <table class="table table-responsive table-striped">
                    <tbody>
                        <tr>
                          <td><?php echo "<div class='info'><b> Student Name</b>:  "; ?></div></td>
                          <td><div class='info'> <?php echo $row['lastname']." ". $row['firstname']; ?> </div></td>
                        </tr>
                        <tr>
                            <td> <div class='info'><span> <b>Student No.</b>: </div> </span></td>
                            <td> <div class='info'><span> <?php echo $row["studentno"]; ?></div> </span></td>
                           
                        
                        </tr>  
                        <tr>
                          
                            <td><div class='info'><span> <b>Index No.</b>: </div></span> </td>
                            <td><div class='info'><span> <?php echo $row["indexNo"]; ?></div></span> </td>
                        
                        </tr>  
                        <tr>
                            <td> <div class='info'><span> <b>Contact</b>: </div> </span></td>
                            <td> <div class='info'><span>  <?php echo $row["contact"]; ?></div> </span></td>
                            
                        
                        </tr> 
                        <tr>
                          <td> <div class='info'><span> <b>E-mail</b>: </div> </span></td>
                          <td> <div class='info'><span> <?php echo $row["email"]; ?></div> </span></td>
                        </tr>
                        <tr>
                          <td><div class='info'><span><b> Current Year</b>: </div></span></td>
                          <td><div class='info'><span>  <?php $predate = date('Y'); $curdate = $predate - 1;  echo $curdate."/".$predate;  ?>   </div></span></td>

                        </tr>
                        <tr>
                          <td><div class='info'><span><b> Level</b>:  </div> </span> </td>
                          <!-- get info -->
                              <?php   $year = "year"; 
                              $query_year = "SELECT * FROM stuyearnsessions WHERE id = '".$row["yrlevel"]."' and type = '" . $year ."'";
                              $result_year = mysqli_query($con, $query_year);
                                $row_year = mysqli_fetch_assoc($result_year);
                                if($row_year){
                                ?>
                          <td><div class='info'><span> <?php echo $row_year["typename"]."</div>"; //else echo $row['yrlevel']; ?></span> </td>
                                  <?php }
                                  else{
                                    ?>
                          <td><div class='info'><span> <?php echo "Unknown"."</div>"; //else echo $row['yrlevel']; ?></span> </td>

                                    <?php
                                  }
                                  ?>
                        </tr>
                        <tr>
                            <td><div class='info'><span><b> Department</b>:  </div>  </span></td>
                            <?php   $departo = "Department"; 
                              $query_departo = "SELECT * FROM stufacultydepart WHERE id = '".$row["department"]."' and type = '" . $departo ."'";
                              $result_departo = mysqli_query($con, $query_departo);
                                $row_departo = mysqli_fetch_assoc($result_departo);
                                if($row_departo){
                                ?>
                            <td><div class='info'><span>  <?php echo $row_departo["typename"]."</div>"; ?> </span></td>
                            <?php }
                                  else{
                                    ?>
                          <td><div class='info'><span> <?php echo "Unknown"."</div>"; //else echo $row['yrlevel']; ?></span> </td>

                                    <?php
                                  }
                                  ?>
                        </tr>
                        <tr>
                            <td><div class='info'><span><b> Session</b>:   </div>  </span></td>
                            <?php   $sess = "session"; 
                              $query_sess = "SELECT * FROM stuyearnsessions WHERE id = '".$row["session"]."' and type = '" . $sess ."'";
                              $result_sess = mysqli_query($con, $query_sess);
                                $row_sess = mysqli_fetch_assoc($result_sess);
                                if($row_sess){
                                ?>
                            <td><div class='info'><span><?php echo $row_sess["typename"]."</div>"; ?> </span></td>
                            <?php }
                                  else{
                                    ?>
                          <td><div class='info'><span> <?php echo "Unknown"."</div>"; //else echo $row['yrlevel']; ?></span> </td>

                                    <?php
                                  }
                                  ?>
                        </tr>
                        <tr>
                            <td><div class='info'><span><b> Student Status</b>: </div> </span></td>
                            <!--check student status  -->
                            <?php
                            // $statusQuery = mysqli_query($con,"SELECT * FROM students WHERE studentno = '".$row['studentno']."'");
                            // $StatusResult = mysqli_fetch_row($statusQuery);
                            // while($StatusResult){
                              $status_var=$row["status"];
                              if($status_var=='0'){
                                ?>
                                <td><div class="info">Unregistered <span class="glyphicon glyphicon-remove"></span> </div></td>
                                <?php
                               }
                              elseif($status_var=='1'){
                                ?>
                                <td><div class="info">Registered <span class="glyphicon glyphicon-ok"></span> </div></td>
                                <?php
                              }else{
                              ?>
                                <td><div class="info">Unknown <span class="glyphicon glyphicon-repeat"></span></div></td>
                             
                              <?php }  ?>
                        </tr>         
            <?php
                        $query_date = "SELECT DATE_FORMAT(date_joined, '%m/%d/%Y') FROM students WHERE id = '".$_SESSION['userid']."'";
                        $result = mysqli_query($con, $query_date);

                        $rowdate = mysqli_fetch_row($result);
                        ?>   
                        <!-- echo "<div class='info'><strong>Date Joined:</strong> <span>".$row[0]."</span></div>"; -->
                        <tr>
                            <td><div class='info'><span><b> Date Registered</b>: </div> </span></td>
                            <td><div class='info'><span>  <?php echo $rowdate[0]."</div>"; ?></span></td>
                            
                        </tr>   
                               
                  </tbody>
                </table>

<!-- controls -->
          <table class="table table-responsive table-striped">
            <tr>
              <td>  <a  class="btn btn-primary" href="editprofile.php"> <span class="glyphicon glyphicon-edit"></span>  Edit Profile</a> </td>
            <!-- </tr>
            <tr> -->
              <td>  <a class="btn btn-success" href="changepassword.php"><span class="glyphicon glyphicon-pencil"></span>  Change Password</a> </td>
            </tr> 
            <tr> 
              <?php
              // if student is not registered 
              // student cant get acccess to resit registration
              $status_var=$row["status"];
              if($status_var=='1'){
                ?>
              <td> <a class="btn btn-info" href="./courseregistration.php"><span class="glyphicon glyphicon-new-window"></span>  Register Courses</a> </td>
                <!-- else if student has not registered  -->
                 <?php
                        }
                    else{
                      ?>
              <td> <a class="btn btn-danger" href="#" disabled><span class="glyphicon glyphicon-new-window"></span>  Register Courses</a> </td>
                      <?php
                    }
                     ?>
<!--            
            <td>   <a class="btn btn-info" href="#"><span class="glyphicon glyphicon-new-window"></span>  Departmental Registration</a> </td>
           -->
            </tr>
            <tr>
            <td> <button class="btn btn-info btn-sm " data-toggle="modal" data-target="#myModal_dues"><span class='glyphicon glyphicon-pay'></span> How to pay Department Dues</button>
            </td>
            </tr>
          </table>
        
                <!-- <div class="options">
                <a class="btn btn-success" href="changepassword.php">Change Password</a>
                </div> -->
                <!-- <div class="options">
                <a class="btn btn-info" href="./courseregistration.php">Register Courses</a>
                </div> -->
                
                <!-- <div class="options">
                  <a class="btn btn-primary" href="">Payment</a> -->
                  <!-- <a class="btn btn-success" href="changepassword.php">Change Password</a> -->
                  <!-- <a class="btn btn-info" href="./courseregistration.php">Register Courses</a> -->
                  <!-- <a class="btn btn-info" href="././course/index.php">Register Courses</a> -->

                <!-- </div> -->
                
 <!-- make payment informations -->
<!-- Modal -->
<div id="myModal_dues" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Payment Format Info.</h4>
      </div>
      <div class="modal-body">
        
      <div class="list-group">
        <p class="list-group-item active">Use MTN momo payment System</p>
        <ol >
            <p class="list-group-item-heading"> </p>
            <li class="list-group-item-heading">Dial *170#</li>
            <li class="list-group-item-heading">Choose option 1 for "Transfer Money"</li>
            <li class="list-group-item-heading">Choose option 1 for "MoMo User"</li>
            <li class="list-group-item-heading">Enter mobile number <b>0549142719</b></li>
            <li class="list-group-item-heading">Confirm mobile number <b>0549142719</b></li>
            <li class="list-group-item-heading">Enter amount (<b><?php $amoutTotal = 110; echo " GHȻ ".number_format($amoutTotal,2); ?> </b>)</li> <!-- ¢ -->
            <li class="list-group-item-heading">Enter <b><?php echo $_SESSION['studentno']." DepartDues";?></b>  as Reference</li>
            <li class="list-group-item-heading">Enter <b>MM PIN</b> to confirm payment</li>
               
        </ol>
            <p>   You will receive SMS notification an hour after payment for confirmation.</p>
      </div>

    <!-- <a href="#" class="list-group-item active">
      <h4 class="list-group-item-heading">First List Group Item Heading</h4>
      <p class="list-group-item-text">List Group Item Text</p>
    </a>
    <a href="#" class="list-group-item">
      <h4 class="list-group-item-heading">Second List Group Item Heading</h4>
      <p class="list-group-item-text">List Group Item Text</p>
    </a>
    <a href="#" class="list-group-item">
      <h4 class="list-group-item-heading">Third List Group Item Heading</h4>
      <p class="list-group-item-text">List Group Item Text</p>
    </a> -->
  <!-- </div> -->
<!-- </div> -->

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
  
</div>


                
                <!-- Notifications  -->
                <div class="panel panel-white">
                        <div class="panel-heading">
                             <h4 class="panel-title">Notice Board</h4>
                        </div>
                        
                        <div class="panel-body">
                          <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

                            <?php
							include("connect.php");
              // check if date of notice has not passed

              
            
            
							$sql = "SELECT * FROM noticetbl ORDER by noteid DESC";
                            $result = mysqli_query($con,$sql);

                            if (mysqli_num_rows($result) > 0) {
                           $tabno = 1;
                            while($row_notice = mysqli_fetch_assoc($result)) {
                              // get notification per date
                              // $origin = new DateTime($row_notice['postdate']);
                              // $target = new DateTime(date('d M Y'));
                              // $interval = $origin->diff($target);
                              // $dateiff = $interval->format('%a');
                              // if($dateiff <= '7'){

                              
                            print '
							<div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="heading'.$tabno.'">
                            <h5 class="panel-title">
                            <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse'.$tabno.'" aria-expanded="false" aria-controls="collapse'.$tabno.'">
                            '.$row_notice['notice'].'
                            </a>
                            </h5>
                            </div>
                            <div id="collapse'.$tabno.'" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading'.$tabno.'">
                            <div class="panel-body">
                            '.$row_notice['description'].'
							<hr><i class="glyphicon glyphicon-calendar"></i> '.$row_notice['postdate'].' | <i class="glyphicon glyphicon-refresh"></i> '.$row_notice['lastupdate'].'
                            </div>
                            </div>
                            </div>';
					       $tabno++; 
                // }
                             }
                            } else {
                        print '
						<div class="alert alert-info" role="alert">
                          // Nothing was found in database.
                        </div>';
                             }
                            //  mysqli_close($con);
							
							?>

                                        </div>
                                </div>
                            </div>
                        </div>
	

          
                
      </div>


      <?php
        } else {

          die("Error with the query in the database");

        }

      ?>
      
      
      
    </div>

	
 <br>
 <br>
    <?php include("footer.php"); ?>
  </section>


	<script src="assets/js/jquery-3.1.1.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/main.js"></script>
</body>
</html>

<?php


  } else {
    header("location:index.php");
    exit;
  }

  unset($_SESSION['prompt']);
  mysqli_close($con);

?>