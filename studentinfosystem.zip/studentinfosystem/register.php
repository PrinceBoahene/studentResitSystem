<?php 

  session_start();

  require 'connect.php';
  require './functions.php';

// $resetpass = $_SESSION['forgetpass'];

  if(isset($_POST['register'])) {
    // `id`, `password`, `studentno`, `firstname`, `lastname`, `course`, `yrlevel`, `date_joined`, `email`, `indexNo`,
    //  `contact`, `Faculty`, `session`
    $fname = $_POST['firstname']; 
    $lname = $_POST['lastname']; 
 
    $course = $_POST['course']; //department
    $yrlevel = $_POST['yrlevel']; 
    
    $studno = $_POST['studentno'];
    $email = $_POST['email'];
    $indexnum = $_POST['studentIndexno'];
    $faculty = $_POST['faculty'];
    $contact = $_POST['contact'];

    $sesion = $_POST['session'];
    $stuIndexNo = $_POST['studentIndexno'];
    
    $pword = md5($_POST['password']); 
    $confirmedpay = "No";

    $query = "SELECT studentno FROM students WHERE studentno = '$studno'";
    $result = mysqli_query($con,$query);

    if(mysqli_num_rows($result) == 0) {

      $query = "SELECT studentno FROM students WHERE studentno = '$studno'";
      $result = mysqli_query($con,$query);

      if(mysqli_num_rows($result) == 0) {
        $stat = 1;
        $payconfirmMsg = "No Payment";
        $query = "INSERT INTO students (contact,email,session,Faculty, password, studentno,indexNo, firstname, lastname, department, yrlevel, date_joined,status,paymentconfirmMsg)
        VALUES ('$contact','$email','$sesion','$faculty', '$pword', '$studno','$indexnum', '$fname', '$lname', '$course', '$yrlevel', NOW(),'$stat','$payconfirmMsg')";

        if(mysqli_query($con, $query)) {

          $_SESSION['prompt'] = "Account registered. You can now log in.";
          header("location:index.php");
          exit;

        } else {

          die("Error with the query");

        }

      } else {

        $_SESSION['errprompt'] = "That student number already exists.";

      }

    } else {

      $_SESSION['errprompt'] = "Student number already exists.";

    }

  } 


  // $result = mysqli_query($con, "SELECT * FROM stufacultydepart");

?>

<!DOCTYPE html>
<html>
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Register - Student Information System</title>

	<link href="assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/css/main.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    
</head>
<body>

  <?php include 'header.php'; ?>

  <section class="center-text">
    
    <!-- <strong>Create New Account to register now.</strong> -->

    <div class="registration-form box-center clearfix">

    <?php 
        if(isset($_SESSION['errprompt'])) {
          showError();
        }
    ?>
  <legend class="text-center text-info" > Create New Account to register now.</legend>
      <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
      <!-- <form action="./register.php" method="POST"> -->
        
        <div class="row">
          <div class="account-info col-sm-6">
          
            <fieldset>
              <legend>&emsp; &emsp; &emsp; &emsp; &emsp; Student Bio </legend>
              <!-- <?php // if($resetpass == FALSE){

            ?> -->
              <div class="form-group">
                <label for="firstname">First Name</label>
                <input type="text" class="form-control" name="firstname" placeholder="First Name" required>
              </div>

              <div class="form-group">
                <label for="lastname">Last Name</label>
                <input type="text" class="form-control" name="lastname" placeholder="Last Name" required>
              </div>

              <div class="form-group">
                <label for="email">E-mail</label>
                <input type="email" class="form-control" name="email" placeholder="E-mail" required>
              </div>

              <div class="form-group">
                <label for="studentno">Student Number</label>
                <input type="number" class="form-control" name="studentno" placeholder="Student Number (must be unique)" required>
              </div>

              <div class="form-group">
                <label for="studentindexno">Student Index Number</label>
                <input type="number" class="form-control" name="studentIndexno" placeholder="Student Index Number (must be unique)" required>
              </div>

              <div class="form-group">
                <label for="contact">Contact</label>
                <input type="number" class="form-control" name="contact" placeholder="Contact" required>
              </div>

            </fieldset>
          
          </div>


          <div class="personal-info col-sm-6">
            
            <fieldset>
              <!-- <legend>Student Personal Information</legend> -->
              <legend>  .......... </legend>
              
      
              <div class="form-group">
                <label for="faculty">Faculty</label>

					<SELECT NAME="faculty" class="form-control">select
					<OPTION VALUE="select" >Select Faculty
					<?php
					//loop through all table rows
					$level = "faculty";
					$faculty_retrieved = mysqli_query($con, "SELECT * FROM `stufacultydepart` WHERE `type` = '$level'"); 
					while ($row=mysqli_fetch_array($faculty_retrieved)){
					echo "<OPTION VALUE = $row[id]>$row[typename]";
          }
          ?>
          <!-- <option value=" echo $row3[0]; "> echo $row3[1];</option> -->
          
					</SELECT>

              </div>

              <div class="form-group">
                <label for="course">Department</label>

                <SELECT NAME="course" class="form-control">select
                  <OPTION VALUE="select">Select Department
                  <?php
                  //loop through all table rows
                  $level = "department";
                  $faculty_retrieved = mysqli_query($con, "SELECT * FROM `stufacultydepart` WHERE `type` = '$level'"); 
                  while ($row=mysqli_fetch_array($faculty_retrieved)){
                  echo "<OPTION VALUE=$row[id]>$row[typename]";
					
                    }
                    ?>
				    	</SELECT>

              </div>

              <div class="form-group">
                <label for="yrlevel">Year Level</label>

                <SELECT NAME="yrlevel" class="form-control">select
                  <OPTION VALUE="select">Select Year Level
                  <?php
                  //loop through all table rows
                  $level = "year";
                  $year_retrieved = mysqli_query($con, "SELECT * FROM `stuyearnsessions` WHERE `type` = '$level'"); 
                  while ($row=mysqli_fetch_array($year_retrieved)){
                  echo "<OPTION VALUE=$row[id]>$row[typename]";
					
                    }
                    ?>
				    	</SELECT>

              </div>
              <div class="form-group">
                <label for="session">Session</label>

                <SELECT NAME="session" class="form-control">select
                  <OPTION VALUE="select">Select Session
                  <?php
                  //loop through all table rows
                  $level = "session";
                  $year_retrieved = mysqli_query($con, "SELECT * FROM `stuyearnsessions` WHERE `type` = '$level'"); 
                  while ($row=mysqli_fetch_array($year_retrieved)){
                  echo "<OPTION VALUE=$row[id]>$row[typename]";
					
                    }
                    ?>
				    	</SELECT>

              </div>

              <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" placeholder="Password" required>
              </div>
            </fieldset>
            

          </div>
        </div>
        <a href="index.php" class="btn btn-info"><?php   $_SESSION['forgetpass'] = false; ?>Go back</a>
        <input class="btn btn-primary" type="submit" name="register" value="Register">

        


      </form>
    </div>

  </section>


	<script src="assets/js/jquery-3.1.1.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>

<?php 

  unset($_SESSION['errprompt']);
  mysqli_close($con);

?>