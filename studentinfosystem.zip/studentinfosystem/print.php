<?php
  session_start();

require('./fpdf/fpdf.php');
include('./connect.php');
$stuNo = $_SESSION['studentno'];


// class PDF extends FPDF
// {
// /* Page header */
// function Header()
// {
    
//     $this->SetFont('Arial','B',15);
//     /* Move to the right */
//     $this->Cell(60);
  
//     $this->Cell(70,10,'Page Heading',1,0,'C');
    
// }
// /* Page footer */
// function Footer()
// {
//     /* Position at 1.5 cm from bottom */
//     $this->SetY(-15);
//     /* Arial italic 8 */
//     $this->SetFont('Arial','I',8);
//     /* Page number */
//     $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
// }
// }



$pdf = new FPDF();
///var_dump(get_class_methods($pdf));
// set the title
// $pdf->SetTitle('$stuNo_Resit_receipt');

// $pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',10);

$pdf->Ln(8);
$pdf->Cell(50,10,'Printed Date: '.date('d-m-Y').'',0,"L");
// $pdf->ln(3);

// <!-- `password`, `studentno`, `firstname`, `lastname`, `course`, `yrlevel`, `date_joined`,
//  `email`, `indexNo`, `contact`,`Faculty`, `session` -->
// student information
$query2="SELECT * FROM students where studentno= '$stuNo'";
$result2 = mysqli_query($con, $query2);
if($result2 = mysqli_query($con, $query2)) {

    $row2 = mysqli_fetch_assoc($result2);
// while($row2 = mysqli_fetch_array($result2)){
    $pdf->cell(30,5,"Student Name"); $pdf->cell(50,5, ":  ".$row2['lastname']." ".$row2['firstname'],0,1,"L"); 
    
    $pdf->cell(30,5,"Student Number");  $pdf->cell(50,5,":  ".$row2['studentno'],0,1,"L");
    // $pdf->cell(30,5,"Student Name:");  $pdf->cell(50,5, $row2['firstname']." ". $row2['lastname'],0,1,"L");
                            // get level name
                            $year = "year"; 
                              $query_year = "SELECT * FROM stuyearnsessions WHERE id = '".$row2["yrlevel"]."' and type = '" . $year ."'";
                              $result_year = mysqli_query($con, $query_year);
                                $row_year = mysqli_fetch_assoc($result_year);
                            if($row_year){
    $pdf->cell(30,5,"Year Level");  $pdf->cell(50,5,":  ".$row_year['typename'],0,1,"L");
                            }else{
    $pdf->cell(30,5,"Year Level");  $pdf->cell(50,5,":  Unknown",0,1,"L");

                            }
    $pdf->cell(30,5,"E-mail"); $pdf->cell(50,5,":  ".$row2['email'],0,1,"L");
    $pdf->cell(30,5,"Contact");  $pdf->cell(50,5,":  ".$row2['contact'],0,1,"L");
    // get faculty name
      $fat = "Faculty"; 
    $query_fat = "SELECT * FROM stufacultydepart WHERE id = '".$row2['Faculty']."' and type = '" . $fat ."'";
    $result_fat = mysqli_query($con, $query_fat);
      $row_fat = mysqli_fetch_assoc($result_fat);
      if($row_fat){
    $pdf->cell(30,5,"Faculty"); $pdf->cell(50,5,":  ".$row_fat['typename'],0,1,"L");
      }else{
    $pdf->cell(30,5,"Faculty"); $pdf->cell(50,5,":  Unknown",0,1,"L");

      }
    // get department name
       $departo = "Department"; 
    $query_departo = "SELECT * FROM stufacultydepart WHERE id = '".$row2['department']."' and type = '" . $departo ."'";
    $result_departo = mysqli_query($con, $query_departo);
      $row_departo = mysqli_fetch_assoc($result_departo);
      if($row_departo){
    $pdf->cell(30,5,"Department");  $pdf->cell(50,5,":  ".$row_departo['typename'],0,1,"L"); //department
      }else{
    $pdf->cell(30,5,"Department");  $pdf->cell(50,5,":  Unknown",0,1,"L"); //department

      }
    //   get session name
    $ses = "session"; 
                              $query_ses = "SELECT * FROM stuyearnsessions WHERE id = '".$row2["session"]."' and type = '" . $ses ."'";
                              $result_ses = mysqli_query($con, $query_ses);
                                $row_ses = mysqli_fetch_assoc($result_ses);
                            if($row_ses){
    $pdf->cell(30,5,"Session");  $pdf->cell(50,5,":  ".$row_ses['typename'],0,1,"L");
                            }else{
    $pdf->cell(30,5,"Session");  $pdf->cell(50,5,":  Unknown",0,1,"L");

                            }
    $pdf->cell(30,5,"Payment Status"); $pdf->cell(50,5,":  ".$row2['paymentconfirmMsg'],0,1,"L");
}
// print registered paid courses 
$pdf->Ln(15);
$pdf->SetFont('Arial','B',16);
// $pdf->cell()
$pdf->Cell(0,10,'Registered Resit Courses',1,1,"C");
$pdf->SetFont('Arial','B',12);
$pdf->Cell(10,15,'No.',1,0,"C");
$pdf->Cell(110,15,'Course Name',1,0,"C");
$pdf->Cell(30,15,'Course Code',1,0,"C");
// $pdf->Cell(35,8,'Amount',1,0,"C");
$pdf->Cell(40,15,'Inv. Signature',1,0,"C");
// $pdf->Cell(45,8,'Student Number',1);
    // `tbtrialedcourses`(`id`, `stuNo`, `coursecode`, `coursename`, `yrtrialed`, `currentdate`, `payment`, `confirmedPayment
$yes = "Yes";
$query="SELECT * FROM tbtrialedcourses where stuNo= '$stuNo' and confirmedPayment = '$yes'";
$result = mysqli_query($con, $query);
$no=0;
while($row = mysqli_fetch_array($result)){
	$no=$no+1;
	$pdf->Ln(15);
	$pdf->SetFont('Arial','',12);
	$pdf->Cell(10,15,$no,1,0,"C");
	$pdf->Cell(110,15,$row['coursename'],1);
	$pdf->Cell(30,15,$row['coursecode'],1);
	// $pdf->Cell(40,15,$row['payment'],1);
	$pdf->Cell(40,15,"",1);
	// $pdf->Cell(45,8,$row['stuNo'],1);
}

// add admin details
$pdf->Ln(15);
$pdf->SetFont('Arial','',10);
$admin="1";
$query3="SELECT * FROM administor where id= '$admin'";
$result3 = mysqli_query($con, $query3);
if($result3) {
    $row3 = mysqli_fetch_assoc($result3);
    $pdf->Ln(11);

   $pdf->cell(50,5,".............................................",0,1,"L");
   $pdf->cell(50,5,$row3['name'],0,1,"C");
   $pdf->cell(50,5,"OFFICIALLY APPROVED BY:",0,1,"L");  
   $pdf->cell(50,5,"WeDev,",0,1,"R");  
   $pdf->cell(50,5,"wWw,",0,1,"R");  
   $pdf->cell(50,5,"ALL DEPARTMENTAL HEADS",0,1,"R");  
   
   $pdf->Ln(5);
//   $pdf->line();

}


$pdf->Output('$stuNo_Resit_receipt','I');
?>